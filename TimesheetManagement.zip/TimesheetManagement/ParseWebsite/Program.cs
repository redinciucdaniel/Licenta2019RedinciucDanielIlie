﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.SqlTypes;
using System.Globalization;
using System.Linq;
using System.Net.Http;
using System.Text.RegularExpressions;
using HtmlAgilityPack;
using System.Text;
using System.Threading.Tasks;

namespace ParseWebsite
{
    public class Program
    {
        private static string regexLink = "href=\"(.*)\"";
        private static string regexRelativeLink = "href=\"\\.\\./(.*)\"";
        private static string regexTitle = ">(.*)</a>";
        private static string regexDay = "<b>(.*)</b>";
        private static Dictionary<string, string> Translations = new Dictionary<string, string>();
        private static int timesheetVersion { get; set; }

        static void Main(string[] args)
        {
            LoadSubjects().Wait();
            timesheetVersion = CreateNewTimesheetVersion();
            LoadClasses().Wait();
        }

        private static void DefineTranslations()
        {
            Translations.Add("Advanced Programming", "Programare avansata");
            Translations.Add("Algebraic Foundations of Computer Science", "Fundamente algebrice ale informaticii");
            Translations.Add("Algorithm Design", "Proiectarea algoritmilor");
            Translations.Add("Computer graphics", "Grafica pe calculator");
            Translations.Add("DBMS Practice", "Practica SGBD");
            Translations.Add("Numerical calculus", "Calcul numeric");
            Translations.Add("Object-Oriented Programming", "Programare orientata-obiect");
            Translations.Add("Operating Systems", "Sisteme de operare");
            Translations.Add("PedagogieI", "Pedagogie I (Fundamentele pedagogiei + Teoria si metodologia curriculumului)");
            Translations.Add("PedagogieII", "Pedagogie II (Teoria si metodologia instruirii + Teoria si metodologia evaluarii)");
            Translations.Add("Probabilities and Statistics", "Probabilitati si statistica");
            Translations.Add("Programare competitiva II, facultativ, pregatire olimpiada", "Programare competitiva II");
            Translations.Add("Recuperare ore SO", "Sisteme de operare");
            Translations.Add("Recuperare Retele Petri si aplicatii", "Retele Petri si aplicatii");
            Translations.Add("Recuperari Sisteme de operare", "Sisteme de operare");
            Translations.Add("Software Engineering", "Ingineria Programarii");
            Translations.Add("Tehnici de programare e platforma Android", "Tehnici de programare pe platforma Android");
            Translations.Add("Web Technologies", "Tehnologii WEB");
            Translations.Add("Tehnici de ingineria limbajului natural", "Tehnici de Ingineria Limbajului Uman");
            Translations.Add("Limbaje de scripturi (pentru studentii umanisti)", "Limbaje de scripturi");
            Translations.Add("Recuperare Modelarea sistemelor distribuite", "Modelarea sistemelor distribuite");

        }
        private static string GetTranslation(string className)
        {
            string translationString;
            try
            {
                translationString = Translations[className];
            }
            catch (Exception)
            {
                translationString = className;
            }
            return translationString;
        }

        public static int CreateNewTimesheetVersion()
        {
            using (var context = new TSMEntities())
            {
                var currentVersion = (from c in context.tblTimesheetVersions
                    where c.fldTimesheetVersionStartDate < DateTime.Now
                    where c.fldTimesheetVersionEndDate > DateTime.Now
                    select c).FirstOrDefault();

                if (currentVersion != null)
                {
                    var newVersion = new tblTimesheetVersion();
                    newVersion.fldTimesheetVersionStartDate = DateTime.Now;
                    newVersion.fldTimesheetVersionEndDate = (DateTime)SqlDateTime.MaxValue;
                    newVersion.fldTimesheetVersionLastUpdateOn = DateTime.Now;
                    newVersion.fldTimesheetVersionLastUpdateBy = -1;

                    //end the current version
                    currentVersion.fldTimesheetVersionEndDate = DateTime.Now;

                    context.tblTimesheetVersions.Add(newVersion);
                    context.SaveChanges();
                    return newVersion.fldTimesheetVersionID;
                }
                else
                {
                    var firstVersion = new tblTimesheetVersion();
                    firstVersion.fldTimesheetVersionStartDate = (DateTime)SqlDateTime.MinValue;
                    firstVersion.fldTimesheetVersionEndDate = (DateTime)SqlDateTime.MaxValue;
                    firstVersion.fldTimesheetVersionLastUpdateOn = DateTime.Now;
                    firstVersion.fldTimesheetVersionLastUpdateBy = -1;

                    context.tblTimesheetVersions.Add(firstVersion);
                    context.SaveChanges();
                    return firstVersion.fldTimesheetVersionID;
                }
            }
        }
        private static async Task<int> LoadSubjects()
        {
            var bachelorUrl = "https://www.info.uaic.ro/programs/informatica-ro-en/";
            var mastersUrl = "https://www.info.uaic.ro/studii-de-master/";

            //No preprocessing required for the bachelor link:
            ParseSubjectLink(bachelorUrl, "Bachelor").Wait();

            //Masters link contain multiple pages, so we need to extract them all:
            var httpClient = new HttpClient();
            var html = await httpClient.GetStringAsync(mastersUrl);
            var htmlDocument = new HtmlDocument();
            htmlDocument.LoadHtml(html);

            var subjectURLS = htmlDocument.DocumentNode.SelectNodes("//div[@id='main']//div//div[1]//div[1]//div[2]//ul//li[position()<6]");

            foreach (var subjectURL in subjectURLS)
            {
                string subjectURLFull = Regex.Match(subjectURL.InnerHtml, regexLink).Groups[1].Value;
                subjectURLFull = "https://www.info.uaic.ro" + subjectURLFull;
                ParseSubjectLink(subjectURLFull, "Master").Wait();
            }

            //Console.Write("Subjects loaded");
            return 1;
        }
        private static async Task<int> ParseSubjectLink(string subjectURL, string target)
        {
            var httpClient = new HttpClient();
            var html = await httpClient.GetStringAsync(subjectURL);

            var htmlDocument = new HtmlDocument();
            htmlDocument.LoadHtml(html);

            var subjectHtml = htmlDocument.DocumentNode.SelectNodes("//div[@id='main']//div//div[1]//div[1]//div[2]/script/text()");

            HtmlNodeCollection optionalHtml;

            try
            {
                //check if there is a H4 on the page
                var check = htmlDocument.DocumentNode.SelectNodes("//div[@id='main']//div//div[1]//div[1]//div[2]//h4");

                if (check != null)
                {
                    optionalHtml = htmlDocument.DocumentNode.SelectNodes("//div[@id='main']/div/div[1]/div[1]/div[2]/ul/li");
                    using (var context = new TSMEntities())
                    {
                        foreach (var oh in optionalHtml)
                        {
                            //make sure the H4 reffers to an optional discipline
                            if (oh.InnerHtml.Contains("<a class"))
                            {

                                var newSubject = new tblSubject();
                                newSubject.fldSubjectYear = 1;
                                newSubject.fldSubjectSemester = 1;
                                newSubject.fldSubjectName = oh.InnerHtml.Split(',')[0];
                                newSubject.fldSubjectTarget = target;

                                var checkIfExists =
                                    context.tblSubjects.FirstOrDefault(
                                        s => s.fldSubjectName == newSubject.fldSubjectName);
                                if (checkIfExists == null)
                                {
                                    context.tblSubjects.Add(newSubject);
                                }
                            }

                        }
                        context.SaveChanges();
                    }

                }
            }
            catch (Exception)
            {
            }

            string regex = "`(.*\\s.*)*`";
            string rawData = string.Empty;
            Match match = Regex.Match(subjectHtml[0].InnerHtml, regex);
            if (match.Success)
            {
                rawData = match.Value.Replace("`", string.Empty);
            }

            //UPSERT the Available Subjects
            using (var context = new TSMEntities())
            {
                var check = context.tblSubjects.FirstOrDefault(s => s.fldSubjectName == "Unknown");
                if (check == null)
                {
                    var subject = new tblSubject();
                    subject.fldSubjectName = "Unknown";
                    subject.fldSubjectYear = 0;
                    subject.fldSubjectSemester = 0;
                    subject.fldSubjectFile = "";
                    subject.fldSubjectIsFacultative = 1;
                    context.tblSubjects.Add(subject);
                }

                foreach (var line in rawData.Split('\n').Select(s => s.Trim()).ToArray())
                {
                    string[] items = line.Split('|').Select(s => s.Trim()).ToArray();
                    var newSubject = new tblSubject();
                    newSubject.fldSubjectYear = Int32.Parse(items[0]);
                    newSubject.fldSubjectSemester = Int32.Parse(items[1]);
                    newSubject.fldSubjectIsFacultative = items[2].ToUpper().Contains("F") ? 1 : 0;
                    newSubject.fldSubjectName = RemoveDiacritics(items[3]);
                    newSubject.fldSubjectFile = items[5];
                    newSubject.fldSubjectTarget = target;

                    var checkIfExists =
                        context.tblSubjects.FirstOrDefault(s => s.fldSubjectName == newSubject.fldSubjectName);
                    if (checkIfExists == null)
                    {
                        context.tblSubjects.Add(newSubject);
                    }
                }
                context.SaveChanges();
            }
            return 1;
        }


        private static async Task<int> LoadClasses()
        {
            //Populate the dictionary before parsing the links
            DefineTranslations();

            var rootUrl = "https://profs.info.uaic.ro/~orar/globale/orar_complet.html";
            var httpClient = new HttpClient();
            var html = await httpClient.GetStringAsync(rootUrl);

            var htmlDocument = new HtmlDocument();
            htmlDocument.LoadHtml(html);

            var htmlClassNodesList = htmlDocument.DocumentNode.SelectNodes("html/body/table/tr/td[4]").ToList();

            List<string> classLinks = new List<string>();

            foreach (var cls in htmlClassNodesList)
            {
                var matchLink = Regex.Match(cls.InnerHtml, regexRelativeLink);
                var matchTitle = Regex.Match(cls.InnerHtml, regexTitle);

                if (matchLink.Success && matchTitle.Success)
                {
                    //Console.WriteLine(matchLink.Groups[1].Value);
                    if (!classLinks.Contains(matchLink.Groups[1].Value))
                        ParseClassLink(matchLink.Groups[1].Value, matchTitle.Groups[1].Value).Wait();

                    classLinks.Add(matchLink.Groups[1].Value);
                }
            }

            //foreach (var e in classLinks)
            //{
            //    Console.WriteLine(e);
            //}
            return 1;
        }
        private static async Task<int> ParseClassLink(string relativeLink, string subjectName)
        {
            string link = "https://profs.info.uaic.ro/~orar/" + relativeLink;
            var httpClient = new HttpClient();
            httpClient.Timeout = TimeSpan.FromSeconds(120);
            var html = await httpClient.GetStringAsync(link);

            var HtmlDocument = new HtmlDocument();
            HtmlDocument.LoadHtml(html);

            var getLines = HtmlDocument.DocumentNode.SelectNodes("//html//body//table//tr[position()>1]");
            string[] daysOfWeek = { "Luni", "Marti", "Miercuri", "Joi", "Vineri", "Sambata", "Duminica" };
            string currentDay = "Luni";
            using (var context = new TSMEntities())
            {
                foreach (HtmlNode line in getLines)
                {
                    var newClass = new tblClass();
                    int i = 0;
                    newClass.fldDayOfTheWeek = currentDay;

                    foreach (var cell in line.SelectNodes("td").ToList())
                    {
                        #region Check if a day changes    
                        if (daysOfWeek.Any(cell.InnerHtml.Contains))
                        {
                            //Apply the regex for the day of the week cell
                            var matchDay = Regex.Match(cell.InnerHtml, regexDay);

                            //If an event is happening only on a fixed date, store that info as well
                            currentDay = matchDay.Groups[1].Value.Replace("</b><b>, ", "|");
                        }
                        #endregion

                        switch (i)
                        {
                            #region Time From
                            case 0:
                                newClass.fldClassTimeFrom = Regex.Replace(cell.InnerHtml, @"\s+", string.Empty);
                                break;
                            #endregion

                            #region Time To
                            case 1: //
                                newClass.fldClassTimeTo = Regex.Replace(cell.InnerHtml.Trim(), @"\s+", string.Empty);
                                break;
                            #endregion

                            #region Class Name
                            case 2:
                            {
                                newClass.fldClassName = subjectName.Trim();

                                string className = GetTranslation(newClass.fldClassName);
                                if (className == "Pedagogie")
                                {
                                    if (subjectName.Contains("anul 1"))
                                        className = GetTranslation("PedagogieI");
                                    if (subjectName.Contains("anul 2"))
                                        className = GetTranslation("PedagogieII");
                                }
                                var auxClass = context.tblSubjects.FirstOrDefault(
                                    s => s.fldSubjectName == className);

                                if (auxClass == null)
                                {
                                    newClass.fldSubjectID =
                                        context.tblSubjects.FirstOrDefault(s => s.fldSubjectName == "Unknown")
                                            .fldSubjectID;
                                }
                                else
                                {
                                    newClass.fldSubjectID = auxClass.fldSubjectID;
                                }
                            }
                                break;
                            #endregion

                            #region Class Type
                            case 3:
                                newClass.fldClassType = Regex.Replace(cell.InnerHtml, @"\s+", string.Empty);
                                break;
                            #endregion

                            #region Groups
                            case 4:
                                //in case there are multiple groups, make a split and apply the title regex on each part
                                if (cell.InnerHtml.Contains(','))
                                {
                                    string classRooms = String.Empty;
                                    var classRoomsRaw = Regex.Replace(cell.InnerHtml, "\\s+", string.Empty).Split(',');
                                    foreach (var croom in classRoomsRaw)
                                    {
                                        if (Regex.Match(croom, regexTitle).Groups[1].Value != String.Empty)
                                            classRooms +=
                                                Regex.Match(croom, regexTitle).Groups[1].Value
                                                    .Replace(",", String.Empty) + " - ";
                                    }
                                    newClass.fldGroup = classRooms.Remove(classRooms.Length - 2);
                                }
                                else //else apply the regex on the main part
                                {
                                    newClass.fldGroup =
                                        Regex.Match(Regex.Replace(cell.InnerHtml, "\\s+", string.Empty), regexTitle)
                                            .Groups[1].Value;
                                    newClass.fldGroup = newClass.fldGroup.Replace(",", String.Empty);
                                    newClass.fldGroup = newClass.fldGroup.Remove(newClass.fldGroup.Length - 1);
                                }
                                break;
                            #endregion

                            #region Teachers
                            case 5:
                                //in case there are multiple teachers, make a split and apply the title regex on each part
                                if (cell.InnerHtml.Contains("<br>"))
                                {
                                    string teachers = String.Empty;
                                    var teachersRaw = Regex.Replace(cell.InnerHtml, "\\s+", string.Empty).Split(new string[] { "<br>" }, StringSplitOptions.None);
                                    foreach (var teacher in teachersRaw)
                                    {
                                        teachers += Regex.Match(teacher, regexTitle).Groups[1].Value + " - ";
                                    }
                                    newClass.fldClassTeacher = teachers.Remove(teachers.Length - 2);
                                }
                                else //else apply the regex on the main part
                                {
                                    newClass.fldClassTeacher =
                                        Regex.Match(Regex.Replace(cell.InnerHtml, "\\s+", string.Empty), regexTitle)
                                            .Groups[1].Value;
                                };
                                break;


                            #endregion

                            #region Rooms
                            case 6:
                                //in case there are multiple rooms, make a split and apply the title regex on each part
                                if (cell.InnerHtml.Contains(','))
                                {
                                    string classRooms = String.Empty;
                                    var classRoomsRaw = Regex.Replace(cell.InnerHtml, "\\s+", string.Empty).Split(',');
                                    foreach (var croom in classRoomsRaw)
                                    {
                                        string regexMatchRoom = Regex.Match(croom, regexTitle).Groups[1].Value;

                                        if (regexMatchRoom != String.Empty & !regexMatchRoom.ToUpper().Contains("LAPTOP"))
                                            classRooms += Regex.Match(croom, regexTitle).Groups[1].Value
                                                              .Replace(",", String.Empty) + " - ";
                                    }
                                    if (classRooms.Length >= 2)
                                        newClass.fldClassRoom = classRooms.Remove(classRooms.Length - 2);
                                }
                                else //else apply the regex on the main part
                                {
                                    newClass.fldClassRoom =
                                        Regex.Match(Regex.Replace(cell.InnerHtml, "\\s+", string.Empty), regexTitle)
                                            .Groups[1].Value;
                                }
                                break;
                            #endregion

                            #region Optional Package
                            case 7:
                                newClass.fldOptionalPackage =
                                    Regex.Replace(cell.InnerHtml, "\\s+", string.Empty);
                                if (newClass.fldOptionalPackage.Trim() == "&nbsp;")
                                    newClass.fldOptionalPackage = "";
                                break;
                            #endregion

                            #region Optional Package
                            case 8:
                                if (newClass.fldOptionalPackage == "" || newClass.fldOptionalPackage.ToLower().Contains("pare"))
                                {
                                    newClass.fldOptionalPackage = Regex.Replace(cell.InnerHtml, "\\s+", string.Empty);
                                    if (newClass.fldOptionalPackage.Trim() == "&nbsp;")
                                        newClass.fldOptionalPackage = "";
                                }
                                break;
                            #endregion

                        }

                        i++;
                    }

                    if (newClass.fldClassName != null)
                    {
                        newClass.fldClassName = GetTranslation(newClass.fldClassName);
                        newClass.fldTimesheetVersionID = timesheetVersion;
                        context.tblClasses.Add(newClass);
                    }
                }
                context.SaveChanges();
            }
            return 1;
        }

        static string RemoveDiacritics(string text)
        {
            var normalizedString = text.Normalize(NormalizationForm.FormD);
            var stringBuilder = new StringBuilder();

            foreach (var c in normalizedString)
            {
                var unicodeCategory = CharUnicodeInfo.GetUnicodeCategory(c);
                if (unicodeCategory != UnicodeCategory.NonSpacingMark)
                {
                    stringBuilder.Append(c);
                }
            }

            return stringBuilder.ToString().Normalize(NormalizationForm.FormC);
        }
    }
}
