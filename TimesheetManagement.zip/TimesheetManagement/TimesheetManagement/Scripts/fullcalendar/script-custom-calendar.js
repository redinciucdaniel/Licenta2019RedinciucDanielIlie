﻿$(document).ready(function () {
    $('#calendar').fullCalendar({
        default: 'agendaWeek',
        header:
        {
            left: 'prev,next today',
            center: 'title',
            right: 'agendaWeek, agendaDay' //month can be added
        },
        buttonText: {
            today: 'today',
            month: 'month',
            week: 'week',
            day: 'day'
        },

        events: function (start, end, timezone, callback) {
            $.ajax({
                url: '/MySchedule/GetCalendarData',
                type: "GET",
                dataType: "JSON",

                success: function (result) {
                    var events = [];

                    $.each(result, function (i, data) {
                        events.push(
                            {
                                title: data.EventTitle,
                                description: data.EventDescription,
                                start: moment(data.EventStartTime).format('YYYY-MM-DD HH:mm'),
                                end: moment(data.EventEndTime).format('YYYY-MM-DD HH:mm'),
                                backgroundColor: data.EventThemeColor
                                //,
                                //borderColor: "#fc0101"
                            });
                    });

                    callback(events);
                }
            });
        },
        eventClick: function (calEvent, jsEvent, view) {
            $('#myModal #eventTitle').text(calEvent.EventTitle);
            var $description = $('<div/>');
            $description.append($('<p/>')
                .html('<b>Start: </b>' + calEvent.start.format("DD-MMM-YYYY HH:mm a")));
            if (calEvent.end !== null) {
                $description.append($('<p/>')
                    .html('<b>End: </b>' + calEvent.end.format("DD-MMM-YYYY HH:mm a")));
            }
            $description.append($('<p/>').html('<b>Description: </b>' + calEvent.description));
            $('#myModal #pDetails').empty().html($description);

            $('#myModal').modal();

        },


        eventRender: function (event, element) {
            element.qtip(
                {
                    content: event.description
                });
        },

        editable: false
    });
});  