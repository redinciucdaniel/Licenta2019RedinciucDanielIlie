﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Web;
using ParseWebsite;

namespace TimesheetManagement.Auxx
{
    public class Utils
    {
        public static int GetDayOfWeek(string dayOfWeek)
        {
            switch (dayOfWeek)
            {
                case "Luni":
                    return 0;
                case "Marti":
                    return 1;
                case "Miercuri":
                    return 2;
                case "Joi":
                    return 3;
                case "Vineri":
                    return 4;
                case "Sambata":
                    return 5;
                case "Duminica":
                    return 6;
                default:
                    return 6;
            }
        }

        public List<string> GetAllAvailableGroups()
        {
            using (var context = new TSMEntities())
            {
                List<string> AllAvailableGroups = new List<string>();
                var allGroupsList = context.tblClasses.Select(c => c.fldGroup).Distinct().ToList();

                var excludedGroups = new[] { "I1", "I2", "I3", "I1A", "I1B", "I1E", "I2A", "I2B", "I3A", "I3B", "I3E" };
                foreach (var group in allGroupsList)
                {
                    if (group.Contains("-"))
                    {
                        var splitList = group.Split('-');
                        foreach (var item in splitList)
                        {
                            if (!excludedGroups.Contains(item.Trim()))
                                AllAvailableGroups.Add(item.Trim());
                        }
                    }
                }

                AllAvailableGroups.Sort();
                AllAvailableGroups = AllAvailableGroups.Distinct().ToList();
                return AllAvailableGroups;
            }
        }

        public static string CreateMD5(string input)
        {
            StringBuilder hash = new StringBuilder();
            MD5CryptoServiceProvider md5provider = new MD5CryptoServiceProvider();
            byte[] bytes = md5provider.ComputeHash(new UTF8Encoding().GetBytes(input));

            for (int i = 0; i < bytes.Length; i++)
            {
                hash.Append(bytes[i].ToString("x2"));
            }
            return hash.ToString();
        }

        public static bool ContainsAny(string haystack, params string[] needles)
        {
            foreach (string needle in needles)
            {
                if (haystack.Contains(needle))
                    return true;
            }

            return false;
        }

    }
}