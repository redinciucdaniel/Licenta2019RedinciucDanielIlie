﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.Entity.Core.Objects;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ParseWebsite;
using TimesheetManagement.Models;

namespace TimesheetManagement.Controllers
{
    public class StudentInfoController : Controller
    {
        // GET: StudentInfo
        public ActionResult Index()
        {
            try
            {
                int userID;
                if (Session["userID"] != null)
                {
                    userID = (int) Session["userID"];
                    using (var context = new TSMEntities())
                    {
                        var user = context.tblUsers.FirstOrDefault(u => u.fldUserID == userID);
                        return View(user);
                    }
                }
                else
                {
                    return View("Error");
                }
            }
            catch (Exception)
            {
                return View("Error");
            }
        }

        [HttpGet]
        public ActionResult UpdateInfo()
        {
            using (var context = new TSMEntities())
            {
                UserGroupModel editUser = new UserGroupModel();
                int loggedId = 0;
                try
                {
                    loggedId = (int) Session["userID"];
                }
                catch (Exception)
                {
                    return View("Error");
                }
                if (loggedId != 0)
                {
                    editUser.User = context.tblUsers.FirstOrDefault(u => u.fldUserID == loggedId);
                    editUser.AvailableGroups = new List<string>();
                    var allGroupsList = context.tblClasses.Select(c => c.fldGroup).Distinct().ToList();

                    var excludedGroups = new[] { "I1", "I2", "I3", "I1A", "I1B", "I1E", "I2A", "I2B", "I3A", "I3B","I3E" };
                    foreach (var group in allGroupsList)
                    {
                        if (group.Contains("-"))
                        {
                            var splitList = group.Split('-');
                            foreach (var item in splitList)
                            {
                                if(!excludedGroups.Contains(item.Trim()))
                                    editUser.AvailableGroups.Add(item.Trim());
                            }
                        }
                    }

                    editUser.AvailableGroups.Sort();
                    editUser.AvailableGroups = editUser.AvailableGroups.Distinct().ToList();
                    
                    return View(editUser);
                }
            }
            return View("Error");
        }

        [HttpPost]
        public ActionResult UpdateInfo(UserGroupModel userToEdit)
        {
            using (var context = new TSMEntities())
            {
                int loggedUserID = (int)Session["userID"];
                int updateNeeded = 0;
       
                if (loggedUserID != 0)
                {
                    var currentUser = context.tblUsers.FirstOrDefault(u => u.fldUserID == loggedUserID);

                        currentUser.fldFirstName = userToEdit.User.fldFirstName;
                        currentUser.fldLastName = userToEdit.User.fldLastName;
                        currentUser.fldDateOfBirth = userToEdit.User.fldDateOfBirth;
                        currentUser.fldUsername = userToEdit.User.fldUsername;
                        currentUser.fldGender = userToEdit.User.fldGender;
                        currentUser.fldAddress = userToEdit.User.fldAddress;
                        currentUser.fldEmail = userToEdit.User.fldEmail;

                        if (currentUser.fldGroup != userToEdit.User.fldGroup)
                        {
                            updateNeeded = 1;
                        }
                        currentUser.fldGroup = userToEdit.User.fldGroup;

                        context.SaveChanges();

                        if (updateNeeded == 1)
                        {
                            context.Database.ExecuteSqlCommand("exec spUpdateClassLinks @fldUserID, @fldGroupName",
                                new SqlParameter("@fldUserID", currentUser.fldUserID),
                                new SqlParameter("@fldGroupName", currentUser.fldGroup)
                            );
                        }
                        
                        return RedirectToAction("Index", "StudentInfo");
                    
                }
            }
            return View("Error");
        }
    }
}