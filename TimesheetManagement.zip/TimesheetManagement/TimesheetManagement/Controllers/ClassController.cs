﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Web;
using System.Web.Mvc;
using ParseWebsite;
using TimesheetManagement.Models;
using TimesheetManagement.Auxx;

namespace TimesheetManagement.Controllers
{
    public class ClassController : Controller
    {
        // GET: Class
        public ActionResult Index(int id)
        {
            var classList = new List<ClassModel>();
            int subjectID = 0;
            using(var context = new TSMEntities())
            {
                var timesheetVersion = (from c in context.tblTimesheetVersions
                    where c.fldTimesheetVersionStartDate < DateTime.Now
                    where c.fldTimesheetVersionEndDate > DateTime.Now
                    select c).FirstOrDefault();

                var currentClassLink = context.tblClassLinks.FirstOrDefault(cl => cl.fldClassLinkID == id);
                var currentClass = context.tblClasses.FirstOrDefault(c => c.fldClassID == currentClassLink.fldClassID);
                if (currentClass != null)
                {
                    subjectID = currentClass.fldSubjectID;
                    string classType = currentClass.fldClassType;
                    classList = (from c in context.tblClasses
                        where c.fldSubjectID == subjectID
                        where c.fldClassType == classType
                        where c.fldClassID != currentClassLink.fldClassID
                        where c.fldTimesheetVersionID == timesheetVersion.fldTimesheetVersionID
                        orderby c.fldDayOfTheWeek
                        select new ClassModel()
                        {
                            fldClassID = c.fldClassID,
                            fldClassType = c.fldClassType,
                            fldClassTeacher = c.fldClassTeacher,
                            fldDayOfTheWeek = c.fldDayOfTheWeek,
                            fldClassRoom = c.fldClassRoom,
                            fldClassTimeTo = c.fldClassTimeTo,
                            fldClassName = c.fldClassName,
                            fldClassTimeFrom = c.fldClassTimeFrom,
                            fldGroup = c.fldGroup
                        }).ToList();
                }
            }

            //var utils = new Utils();
            var sortedList = classList.OrderBy(o => Utils.GetDayOfWeek(o.fldDayOfTheWeek)).ToList();
            ViewBag.CurrentClassLink = id;
            return View(sortedList);

        }

        public ActionResult SwitchClass(int newClassID, int currentLinkID)
        {
            try
            {
                int loggedUserID = (int) Session["userID"];
                using (var context = new TSMEntities())
                {
                    var currentClassLink =
                        context.tblClassLinks.FirstOrDefault(cl => cl.fldClassLinkID == currentLinkID);

                    int oldClass = (int)currentClassLink.fldClassID;

                    if (currentClassLink != null)
                    {
                        context.tblClassLinks.Remove(currentClassLink);
                    }

                    var newLink = new tblClassLink();
                    newLink.fldClassID = newClassID;
                    newLink.fldUserID = loggedUserID;
                    newLink.fldIsBacklog = 0;
                    context.tblClassLinks.Add(newLink);

                    context.SaveChanges();

                    return RedirectToAction("Feedback", "Class",
                        new
                        {
                            fromClassID = oldClass,
                            toClassID = newClassID
                        });
                    //return RedirectToAction("Index", "MySchedule");
                }
            }
            catch (Exception)
            {
                return View("Error");
            }
        }

        [HttpGet]
        public ActionResult Feedback(int fromClassID, int toClassID)
        {
            //List<string> reasonsList = new List<string>();
            //reasonsList.Add("I have a job and the hour is not convenient for me");
            //reasonsList.Add("I cannot wake up to early");
            //reasonsList.Add("I cannot focus this late");
            //reasonsList.Add("The new teacher is helping me learn more");
            //reasonsList.Add("The current teacher methods are not working for me");
            //reasonsList.Add("I heard it's easier to promote this class");
            //reasonsList.Add("Others");

            var feedbackModel = new FeedbackModel(fromClassID, toClassID, "");

            return View(feedbackModel);
        }


        public ActionResult Feedback(FeedbackModel feedback)
        {
            using (var context = new TSMEntities())
            {
                var newFeedback = new tblFeedback
                {
                    fldClassIdFrom = feedback.FromClass,
                    fldClassIdTo = feedback.ToClass,
                    fldFeedbackMessage = feedback.ReasonOfChange
                };

                context.tblFeedbacks.Add(newFeedback);
                context.SaveChanges();

                return RedirectToAction("Index", "MySchedule");
            }  
        }
    }
}