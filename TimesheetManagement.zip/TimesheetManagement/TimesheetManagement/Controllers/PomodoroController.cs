﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace TimesheetManagement.Controllers
{
    public class PomodoroController : Controller
    {
        // GET: Pomodoro
        public ActionResult Index()
        {
            return View();
        }
    }
}