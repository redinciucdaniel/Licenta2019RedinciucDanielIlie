﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ParseWebsite;
using TimesheetManagement.Auxx;
using TimesheetManagement.Models;

namespace TimesheetManagement.Controllers
{
    public class ClassBacklogController : Controller
    {
        // GET: ClassBacklog
        public ActionResult Index()
        {
            try
            {
                int loggedUserId = (int) Session["userid"];
                using (var context = new TSMEntities())
                {

                    var timesheetVersion = (from c in context.tblTimesheetVersions
                        where c.fldTimesheetVersionStartDate < DateTime.Now
                        where c.fldTimesheetVersionEndDate > DateTime.Now
                        select c).FirstOrDefault();


                    //var allocatedSubjects = (from s in context.tblSubjects
                    //    join c in context.tblClasses on s.fldSubjectID equals c.fldSubjectID
                    //    join cl in context.tblClassLinks on c.fldClassID equals cl.fldClassID
                    //    where cl.fldUserID == loggedUserId
                    //    where cl.fldIsBacklog != 1
                    //    where c.fldTimesheetVersionID == timesheetVersion.fldTimesheetVersionID
                    //    select s.fldSubjectID).ToList();

                    var allSubjectIDs = (from s in context.tblSubjects
                        select s.fldSubjectID).ToList();

                    var allSubjects = new List<SubjectModel>();

                    //var unallocatedSubjectsIDs = allSubjects.Except(allocatedSubjects).ToList();

                    foreach (var sub in allSubjectIDs)
                    {
                        var currentSubject = context.tblSubjects.First(s => s.fldSubjectID == sub);
                        var auxSubject = new SubjectModel();
                        auxSubject.fldSubjectID = currentSubject.fldSubjectID;
                        auxSubject.fldSubjectSemester = currentSubject.fldSubjectSemester;
                        auxSubject.fldSubjectName = currentSubject.fldSubjectName;
                        auxSubject.fldSubjectYear = currentSubject.fldSubjectYear;
                        auxSubject.fldSubjectFile = currentSubject.fldSubjectFile;
                        auxSubject.fldSubjectIsFacultative = currentSubject.fldSubjectIsFacultative;
                        auxSubject.fldSubjectFrequency = currentSubject.fldSubjectFrequency!=null?"1":"0";

                        allSubjects.Add(auxSubject);
                    }

                    //allSubjects = allSubjects.OrderBy(o => o.fldSubjectTarget).ThenBy(l => l.fldSubjectYear)
                    //    .ThenBy(l => l.fldSubjectSemester).ToList();

                    //var sortedList = classList.OrderBy(o => Utils.GetDayOfWeek(o.fldDayOfTheWeek)).ToList();

                    return View(allSubjects);
                }
            }
            catch (Exception)
            {
                return View("Error");
            }
        }

        [HttpGet]
        public ActionResult SubjectClasses(int id)
        {
            using (var context = new TSMEntities())
            {

                var timesheetVersion = (from c in context.tblTimesheetVersions
                    where c.fldTimesheetVersionStartDate < DateTime.Now
                    where c.fldTimesheetVersionEndDate > DateTime.Now
                    select c).FirstOrDefault();

                var allSubjectClasses = (from c in context.tblClasses
                    join s in context.tblSubjects on c.fldSubjectID equals s.fldSubjectID
                    where s.fldSubjectID == id
                    where c.fldTimesheetVersionID == timesheetVersion.fldTimesheetVersionID
                    select c.fldClassID).ToList();

                int loggedUserID = (int) Session["userID"];

                var classList = new List<ClassModel>();

                foreach (var cls in allSubjectClasses)
                {
                    var currentClass = context.tblClasses.FirstOrDefault(s => s.fldClassID == cls);

                    var checkIfExists = context.tblClassLinks.FirstOrDefault(
                        cl => cl.fldUserID == loggedUserID && cl.fldClassID == currentClass.fldClassID);

                    var auxClass = new ClassModel(
                        currentClass.fldClassID,
                        currentClass.fldClassName,
                        currentClass.fldClassRoom,
                        currentClass.fldDayOfTheWeek,
                        currentClass.fldClassTimeFrom,
                        currentClass.fldClassTimeTo,
                        currentClass.fldClassTeacher,
                        currentClass.fldClassType,
                        currentClass.fldGroup,
                        true,
                        currentClass.fldOptionalPackage,
                        currentClass.fldSubjectID,
                        checkIfExists == null ? false : true);
                    
                    classList.Add(auxClass);
                }
                if (classList.Count == 0)
                    ViewBag.NoData = "There are no classes in this semester!";
                return View(classList);
            }
        }

        [HttpGet]
        public ActionResult Subscribe(int id)
        {
            try
            {
                int loggedUserID;
                loggedUserID = (int) Session["userID"];

                using (var context = new TSMEntities())
                {
                    var classExists = context.tblClasses.FirstOrDefault(c => c.fldClassID == id);
                    if (classExists != null)
                    {
                        var classLinkExists =
                            context.tblClassLinks.FirstOrDefault(cl => cl.fldUserID == loggedUserID &&
                                                                       cl.fldClassID == classExists.fldClassID);
                        if (classLinkExists == null)
                        {
                            var newClassLink = new tblClassLink();
                            newClassLink.fldUserID = loggedUserID;
                            newClassLink.fldClassID = classExists.fldClassID;
                            newClassLink.fldIsBacklog = 1;

                            context.tblClassLinks.Add(newClassLink);
                            context.SaveChanges();
                        }


                        return RedirectToAction("SubjectClasses", "ClassBacklog", new {id = classExists.fldSubjectID});

                    }
                }
            }
            catch (Exception)
            {
                return View("Error");
            
            }
            return View("SubjectClasses");
        }
    }
}