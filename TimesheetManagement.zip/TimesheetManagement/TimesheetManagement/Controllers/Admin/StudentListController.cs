﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ParseWebsite;
using TimesheetManagement.Auxx;
using TimesheetManagement.Models;


namespace TimesheetManagement.Controllers.Admin
{
    public class StudentListController : Controller
    {
        // GET: StudentList
        public ActionResult Index()
        {
            int loggedUserID;
            try
            {
                loggedUserID = (int)Session["userID"];
                using (var context = new TSMEntities())
                {
                    var isAdmin = context.tblUserTypeLinks.FirstOrDefault(utl => utl.fldUserID == loggedUserID);
                    if (isAdmin.fldUserTypeID != 2) //not admin
                        return View("_AccessDenied");
                    else
                    {
                        List<UserModel> studentList = new List<UserModel>();
                        studentList = (from u in context.tblUsers
                            join ut in context.tblUserTypeLinks on u.fldUserID equals ut.fldUserID
                            where ut.fldUserTypeID == 1
                            select new UserModel()
                            {
                                fldUserID = u.fldUserID,
                                fldGroup = u.fldGroup,
                                fldUsername = u.fldUsername,
                                fldAddress = u.fldAddress,
                                fldLastName = u.fldLastName,
                                fldFirstName = u.fldFirstName,
                                fldEmail = u.fldEmail
                            }).ToList();

                        return View(studentList);
                    }

                }
            }
            catch (Exception)
            {
                return View("_AccessDenied");
            }
        }

        [HttpGet]
        public ActionResult StudentEdit(int id)
        {
            int loggedUserID = 0;
            try
            {
                loggedUserID = (int)Session["userID"];
                using (var context = new TSMEntities())
                {
                    var isAdmin = context.tblUserTypeLinks.FirstOrDefault(utl => utl.fldUserID == loggedUserID);
                    if (isAdmin.fldUserTypeID != 2) //not admin
                        return View("_AccessDenied");
                    else
                    {
                        UserGroupModel userToEdit = new UserGroupModel();

                        userToEdit.User = context.tblUsers.FirstOrDefault(u => u.fldUserID == id);
                        userToEdit.AvailableGroups = new List<string>();
                        var allGroupsList = context.tblClasses.Select(c => c.fldGroup).Distinct().ToList();

                        var excludedGroups = new[] { "I1", "I2", "I3", "I1A", "I1B", "I1E", "I2A", "I2B", "I3A", "I3B", "I3E" };
                        foreach (var group in allGroupsList)
                        {
                            if (group.Contains("-"))
                            {
                                var splitList = group.Split('-');
                                foreach (var item in splitList)
                                {
                                    if (!excludedGroups.Contains(item.Trim()))
                                        userToEdit.AvailableGroups.Add(item.Trim());
                                }
                            }
                        }

                        userToEdit.AvailableGroups.Sort();
                        userToEdit.AvailableGroups = userToEdit.AvailableGroups.Distinct().ToList();
                        return View(userToEdit);
                    }
                }
            }
            catch (Exception)
            {
                return View("_AccessDenied");
            }
        }

        [HttpPost]
        public ActionResult StudentEdit(UserGroupModel userToEdit)
        {
            int loggedUserID = 0;
            try
            {
                loggedUserID = (int) Session["userID"];
                using (var context = new TSMEntities())
                {
                    var isAdmin = context.tblUserTypeLinks.FirstOrDefault(utl => utl.fldUserID == loggedUserID);
                    if (isAdmin.fldUserTypeID != 2) //not admin
                        return View("_AccessDenied");
                    else
                    {
                        var currentUser = context.tblUsers.FirstOrDefault(u => u.fldUserID == userToEdit.User.fldUserID);

                        currentUser.fldFirstName = userToEdit.User.fldFirstName;
                        currentUser.fldLastName = userToEdit.User.fldLastName;
                        currentUser.fldDateOfBirth = userToEdit.User.fldDateOfBirth;
                        currentUser.fldUsername = userToEdit.User.fldUsername;
                        currentUser.fldGender = userToEdit.User.fldGender;
                        currentUser.fldAddress = userToEdit.User.fldAddress;
                        currentUser.fldEmail = userToEdit.User.fldEmail;

                        int updateNeeded = 0;
                        if (currentUser.fldGroup != userToEdit.User.fldGroup)
                        {
                            updateNeeded = 1;
                        }
                        currentUser.fldGroup = userToEdit.User.fldGroup;

                        context.SaveChanges();

                        if (updateNeeded == 1)
                        {
                            context.Database.ExecuteSqlCommand("exec spUpdateClassLinks @fldUserID, @fldGroupName",
                                new SqlParameter("@fldUserID", currentUser.fldUserID),
                                new SqlParameter("@fldGroupName", currentUser.fldGroup)
                            );
                        }

                        return RedirectToAction("Index", "StudentList");
                    }
                }

            }
            catch (Exception)
            {
                return View("_AccessDenied");
            }
        }

        [HttpGet]
        public ActionResult AddNewUser()
        {
            int loggedUserID = 0;
            try
            {
                loggedUserID = (int) Session["userID"];
                using (var context = new TSMEntities())
                {
                    var isAdmin = context.tblUserTypeLinks.FirstOrDefault(utl => utl.fldUserID == loggedUserID);
                    if (isAdmin.fldUserTypeID != 2) //not admin
                        return View("_AccessDenied");
                    else
                    {
                        var utils = new Utils();
                        var newUser = new UserGroupModel();
                        newUser.User = new tblUser();
                        newUser.AvailableGroups = new List<string>();
                        newUser.AvailableGroups = utils.GetAllAvailableGroups();
                        return View(newUser);
                    }
                }
            }
            catch (Exception)
            {
                return View("_AccessDenied");
            }
        }

        [HttpPost]
        public ActionResult AddNewUser(UserGroupModel newUserForm)
        {
            int loggedUserID = 0;
            try
            {
                loggedUserID = (int)Session["userID"];
                using (var context = new TSMEntities())
                {
                    var isAdmin = context.tblUserTypeLinks.FirstOrDefault(utl => utl.fldUserID == loggedUserID);
                    if (isAdmin.fldUserTypeID != 2) //not admin
                        return View("_AccessDenied");
                    else
                    {
                        var newUser = new tblUser();
                        newUser.fldFirstName = newUserForm.User.fldFirstName;
                        newUser.fldLastName = newUserForm.User.fldLastName;
                        newUser.fldAddress = newUserForm.User.fldAddress;
                        newUser.fldDateOfBirth = newUserForm.User.fldDateOfBirth;
                        newUser.fldEmail = newUserForm.User.fldEmail;
                        newUser.fldGender = newUserForm.User.fldGender;
                        newUser.fldUsername = newUserForm.User.fldUsername;
                        newUser.fldPassword = Utils.CreateMD5(Utils.CreateMD5(newUserForm.User.fldPassword));
                        newUser.fldGroup = newUserForm.User.fldGroup;

                        context.tblUsers.Add(newUser);
                        context.SaveChanges();

                        //Create user type
                        var userType = new tblUserTypeLink();
                        userType.fldUserID = newUser.fldUserID;
                        userType.fldUserTypeID = 1;
                        userType.fldUserTypeLinkStartDate = DateTime.Now;
                        userType.fldUserTypeLinkEndDate = DateTime.MaxValue;
                        context.tblUserTypeLinks.Add(userType);
                        context.SaveChanges();

                        //Create class links
                        context.Database.ExecuteSqlCommand("exec spUpdateClassLinks @fldUserID, @fldGroupName",
                            new SqlParameter("@fldUserID", newUser.fldUserID),
                            new SqlParameter("@fldGroupName", newUser.fldGroup)
                        );

                        return RedirectToAction("Index", "StudentList");
                    }
                }
            }
            catch (Exception)
            {
                return View("_AccessDenied");
            }
        }

        public ActionResult StudentDelete(int id)
        {
            int loggedUserID = 0;
            try
            {
                loggedUserID = (int)Session["userID"];
                using (var context = new TSMEntities())
                {
                    var isAdmin = context.tblUserTypeLinks.FirstOrDefault(utl => utl.fldUserID == loggedUserID);
                    if (isAdmin.fldUserTypeID != 2) //not admin
                        return View("_AccessDenied");
                    else
                    {
                        var studentToDelete = context.tblUsers.FirstOrDefault(u =>u.fldUserID == id);
                        //var studentLinkToDelete = context.tblUserTypeLinks.FirstOrDefault(u => u.fldUserID == id);
                        //context.tblUserTypeLinks.Remove(studentLinkToDelete);
                        context.tblUsers.Remove(studentToDelete);
                        context.SaveChanges();
                    }
                    return RedirectToAction("Index", "StudentList");
                }
            }
            catch (Exception)
            {
                return View("_AccessDenied");
            }
        }

        public ActionResult StudentDetails(int id)
        {
            int loggedID = 0;
            try
            {
                loggedID = (int)Session["userID"];
            }
            catch (Exception)
            {
                return View("Error");
            }

            ScheduleModel userClasses = new ScheduleModel();
            using (var context = new TSMEntities())
            {
                var timesheetVersion = (from c in context.tblTimesheetVersions
                    where c.fldTimesheetVersionStartDate < DateTime.Now
                    where c.fldTimesheetVersionEndDate > DateTime.Now
                    select c).FirstOrDefault();

                string[] Exams = { "Examen", "Restante", "Testpractic", "Proiecte" };
                string[] Mandatory = { "Laborator", "Seminar", "Curs" };
                string[] NoChangeAllowed = { "Curs", "Examen", "Restante", "Testpractic" };

                List<tblClassLink> classLinksIDList = new List<tblClassLink>();
                classLinksIDList = (from cl in context.tblClassLinks
                    join c in context.tblClasses on cl.fldClassID equals c.fldClassID
                    where cl.fldUserID == id
                    where c.fldTimesheetVersionID == timesheetVersion.fldTimesheetVersionID
                    select cl).ToList();

                userClasses.MandatoryList = new List<ClassModel>();
                userClasses.OptionalList = new List<ClassModel>();
                userClasses.ExamsList = new List<ClassModel>();
                userClasses.OthersList = new List<ClassModel>();

                foreach (var classLink in classLinksIDList)
                {
                    ClassModel newClass = new ClassModel();
                    var cl = context.tblClasses.FirstOrDefault(c => c.fldClassID == classLink.fldClassID);

                    newClass.fldClassLinkID = classLink.fldClassLinkID;
                    newClass.fldClassID = cl.fldClassID;
                    newClass.fldClassName = cl.fldClassName;
                    newClass.fldClassRoom = cl.fldClassRoom;
                    newClass.fldClassTeacher = cl.fldClassTeacher;
                    newClass.fldClassTimeFrom = cl.fldClassTimeFrom;
                    newClass.fldClassTimeTo = cl.fldClassTimeTo;
                    newClass.fldDayOfTheWeek = cl.fldDayOfTheWeek;
                    newClass.fldClassType = cl.fldClassType;
                    newClass.fldGroup = cl.fldGroup;
                    newClass.fldSubjectID = cl.fldSubjectID;
                    newClass.fldOptionalPackage = cl.fldOptionalPackage;
                    newClass.Editable = !NoChangeAllowed.Contains(cl.fldClassType);

                    if (Exams.Contains(newClass.fldClassType))
                    {
                        userClasses.ExamsList.Add(newClass);
                    }
                    else if (Mandatory.Contains(newClass.fldClassType))
                    {
                        var subject =
                            context.tblSubjects.FirstOrDefault(s => s.fldSubjectID == newClass.fldSubjectID);
                        int n;
                        bool isOptional = int.TryParse(newClass.fldOptionalPackage, out n);

                        if (subject.fldSubjectIsFacultative == 1)
                        {
                            userClasses.OthersList.Add(newClass);
                        }
                        else if (isOptional)
                        {
                            userClasses.OptionalList.Add(newClass);
                        }
                        else
                        {
                            userClasses.MandatoryList.Add(newClass);
                        }
                    }
                    else
                    {
                        userClasses.OthersList.Add(newClass);
                    }
                }

                if (userClasses.MandatoryList.Count > 0 || userClasses.ExamsList.Count > 0 || userClasses.OthersList.Count > 0)
                {
                    userClasses.MandatoryList = userClasses.MandatoryList
                        .OrderBy(o => Utils.GetDayOfWeek(o.fldDayOfTheWeek)).ThenBy(l => l.fldClassTimeFrom).ToList();
                    userClasses.ExamsList = userClasses.ExamsList.OrderBy(o => Utils.GetDayOfWeek(o.fldDayOfTheWeek))
                        .ThenBy(l => l.fldClassTimeFrom).ToList();
                    userClasses.OthersList = userClasses.OthersList.OrderBy(o => Utils.GetDayOfWeek(o.fldDayOfTheWeek))
                        .ThenBy(l => l.fldClassTimeFrom).ToList();
                    userClasses.OptionalList = userClasses.OptionalList.OrderBy(o => Utils.GetDayOfWeek(o.fldDayOfTheWeek))
                        .ThenBy(l => l.fldClassTimeFrom).ToList();

                    return View(userClasses);
                }
                else
                    return View("NoGroupError");
            }
        }
    }
}