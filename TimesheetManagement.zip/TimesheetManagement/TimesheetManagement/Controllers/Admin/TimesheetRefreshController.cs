﻿using System;
using System.Diagnostics;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace TimesheetManagement.Controllers.Admin
{
    public class TimesheetRefreshController : Controller
    {
        // GET: TimesheetRefresh
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Refresh()
        {
            //await ParseWebsite.Program.RefreshData();
            try
            {
                using (Process myProcess = new Process())
                {
                    myProcess.StartInfo.UseShellExecute = false;
                    myProcess.StartInfo.FileName = "D:\\ParseWebsite\\ParseWebsite\\bin\\Debug\\ParseWebsite.exe";
                    myProcess.StartInfo.CreateNoWindow = true;
                    myProcess.Start();
                    return RedirectToAction("Index", "AdminHome");
                }
            }
            catch (Exception)
            {
                return View("_AccessDenied");
            }  
        }
    }
}