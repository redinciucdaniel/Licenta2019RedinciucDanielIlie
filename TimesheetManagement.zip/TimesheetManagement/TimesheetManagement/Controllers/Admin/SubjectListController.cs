﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.UI.WebControls;
using Microsoft.Ajax.Utilities;
using ParseWebsite;
using TimesheetManagement.Auxx;
using TimesheetManagement.Models;

namespace TimesheetManagement.Controllers.Admin
{
    public class SubjectListController : Controller
    {
        // GET: SubjectList
        public ActionResult Index()
        {
            int loggedUserID;
            try
            {
                loggedUserID = (int) Session["userID"];
                using (var context = new TSMEntities())
                {
                    var isAdmin = context.tblUserTypeLinks.FirstOrDefault(utl => utl.fldUserID == loggedUserID);
                    if (isAdmin.fldUserTypeID != 2) //not admin
                        return View("_AccessDenied");
                    return View();
                }
            }
            catch (Exception)
            {
                return View("_AccessDenied");
            }
        }

        public ActionResult ManageClasses()
        {
            int loggedUserID;
            try
            {
                loggedUserID = (int)Session["userID"];
                using (var context = new TSMEntities())
                {
                    var isAdmin = context.tblUserTypeLinks.FirstOrDefault(utl => utl.fldUserID == loggedUserID);
                    if (isAdmin.fldUserTypeID != 2) //not admin
                        return View("_AccessDenied");
                    else
                    {
                        var timesheetVersion = (from c in context.tblTimesheetVersions
                            where c.fldTimesheetVersionStartDate < DateTime.Now
                            where c.fldTimesheetVersionEndDate > DateTime.Now
                            select c).FirstOrDefault();

                        List<ClassModel> classList = new List<ClassModel>();
                        classList = (from c in context.tblClasses
                            where c.fldTimesheetVersionID == timesheetVersion.fldTimesheetVersionID
                            select new ClassModel()
                            {
                                fldClassID = c.fldClassID,
                                fldSubjectID = c.fldSubjectID,
                                fldClassType = c.fldClassType,
                                fldGroup = c.fldGroup,
                                fldDayOfTheWeek = c.fldDayOfTheWeek,
                                fldClassName = c.fldClassName,
                                fldClassRoom = c.fldClassRoom,
                                fldClassTeacher = c.fldClassTeacher,
                                fldClassTimeFrom = c.fldClassTimeFrom,
                                fldClassTimeTo = c.fldClassTimeTo
                            }).ToList();
                        classList = classList.OrderBy(o => Utils.GetDayOfWeek(o.fldDayOfTheWeek)).ThenBy(l => l.fldClassTimeFrom).ToList();
                        return View(classList);
                    }
                }
            }
            catch (Exception)
            {
                return View("_AccessDenied");
            } 
        }

        public ActionResult ManageSubjects()
        {
            int loggedUserID;
            try
            {
                loggedUserID = (int)Session["userID"];
                using (var context = new TSMEntities())
                {
                    var isAdmin = context.tblUserTypeLinks.FirstOrDefault(utl => utl.fldUserID == loggedUserID);
                    if (isAdmin.fldUserTypeID != 2) //not admin
                        return View("_AccessDenied");
                    else
                    {
                        List<SubjectModel> subjectList = new List<SubjectModel>();
                        subjectList = (from s in context.tblSubjects
                            where s.fldSubjectName != "Unknown"
                            select new SubjectModel()
                            {
                                fldSubjectID = s.fldSubjectID,
                                fldSubjectFile = s.fldSubjectFile,
                                fldSubjectSemester = s.fldSubjectSemester,
                                fldSubjectName = s.fldSubjectName,
                                fldSubjectIsFacultative = s.fldSubjectIsFacultative,
                                fldSubjectYear = s.fldSubjectYear,
                                fldSubjectTarget = s.fldSubjectTarget
                            }).ToList();

                        subjectList = subjectList.OrderBy(l => l.fldSubjectTarget)
                            .ThenBy(l => l.fldSubjectYear)
                            .ThenBy(l => l.fldSubjectSemester).ThenBy(l => l.fldSubjectName).ToList();

                        return View(subjectList);
                    }
                }
            }
            catch (Exception)
            {
                return View("_AccessDenied");
            }
        }

        [HttpGet]
        public ActionResult EditClass(int id)
        {
            using (var context = new TSMEntities())
            {
                var currentClass = (from c in context.tblClasses
                    where c.fldClassID == id
                    select new ClassModel()
                    {
                        fldClassID = c.fldClassID,
                        fldSubjectID = c.fldSubjectID,
                        fldClassType = c.fldClassType,
                        fldDayOfTheWeek = c.fldDayOfTheWeek,
                        fldClassName = c.fldClassName,
                        fldClassRoom = c.fldClassRoom,
                        fldClassTeacher = c.fldClassTeacher,
                        fldGroup = c.fldGroup,
                        fldClassTimeFrom = c.fldClassTimeFrom,
                        fldClassTimeTo = c.fldClassTimeTo
                    }).First();
                return View(currentClass);
            }
        }

        [HttpPost]
        public ActionResult EditClass(ClassModel classToEdit)
        {
            using (var context = new TSMEntities())
            {
                var currentClass = context.tblClasses.FirstOrDefault(c => c.fldClassID == classToEdit.fldClassID);

                currentClass.fldClassName = classToEdit.fldClassName;
                currentClass.fldClassRoom = classToEdit.fldClassRoom;
                currentClass.fldClassTeacher = classToEdit.fldClassTeacher;
                currentClass.fldClassTimeFrom = classToEdit.fldClassTimeFrom;
                currentClass.fldClassTimeTo = classToEdit.fldClassTimeTo;
                currentClass.fldClassType = classToEdit.fldClassType;
                currentClass.fldDayOfTheWeek = classToEdit.fldDayOfTheWeek;
                //currentClass.fldGroup = classToEdit.fldGroup;

                context.SaveChanges();

                return RedirectToAction("ManageClasses", "SubjectList");
            }
        }

        public ActionResult DeleteClass(int id)
        {
            int loggedUserID;
            try
            {
                loggedUserID = (int)Session["userID"];
                using (var context = new TSMEntities())
                {
                    var isAdmin = context.tblUserTypeLinks.FirstOrDefault(utl => utl.fldUserID == loggedUserID);
                    if (isAdmin.fldUserTypeID != 2) //not admin
                        return View("_AccessDenied");

                    var classToDelete = context.tblClasses.FirstOrDefault(c=>c.fldClassID == id);

                    context.tblClasses.Remove(classToDelete);
                    context.SaveChanges();
                    return RedirectToAction("ManageClasses", "SubjectList");
                }
            }
            catch (Exception)
            {
                return View("_AccessDenied");
            }
        }

        [HttpGet]
        public ActionResult EditSubject(int id)
        {
            using (var context = new TSMEntities())
            {
                var currentSubject = (from s in context.tblSubjects
                    where s.fldSubjectID == id
                    select new SubjectModel()
                    {
                        fldSubjectID = s.fldSubjectID,
                        fldSubjectName = s.fldSubjectName,
                        fldSubjectTarget = s.fldSubjectTarget,
                        fldSubjectYear = s.fldSubjectYear,
                        fldSubjectSemester = s.fldSubjectSemester,
                        fldSubjectFile = s.fldSubjectFile,
                        fldSubjectFrequency = s.fldSubjectFrequency,
                        fldSubjectIsFacultative = s.fldSubjectIsFacultative
                    }).First();
                return View(currentSubject);
            }
        }

        [HttpPost]
        public ActionResult EditSubject(SubjectModel subjectToEdit)
        {
            using (var context = new TSMEntities())
            {
                var currentSubject = context.tblSubjects.FirstOrDefault(c => c.fldSubjectID == subjectToEdit.fldSubjectID);

                currentSubject.fldSubjectName = subjectToEdit.fldSubjectName.IsNullOrWhiteSpace()
                    ? currentSubject.fldSubjectName
                    : subjectToEdit.fldSubjectName;
                currentSubject.fldSubjectTarget = subjectToEdit.fldSubjectTarget.IsNullOrWhiteSpace()
                    ? currentSubject.fldSubjectTarget
                    : subjectToEdit.fldSubjectTarget;
                currentSubject.fldSubjectYear = subjectToEdit.fldSubjectYear == 0
                    ? currentSubject.fldSubjectYear
                    : subjectToEdit.fldSubjectYear;
                currentSubject.fldSubjectSemester = subjectToEdit.fldSubjectSemester == 0
                    ? currentSubject.fldSubjectSemester
                    : subjectToEdit.fldSubjectSemester;
                currentSubject.fldSubjectFile = subjectToEdit.fldSubjectFile.IsNullOrWhiteSpace()
                    ? currentSubject.fldSubjectFile
                    : subjectToEdit.fldSubjectFile;
                currentSubject.fldSubjectFrequency = subjectToEdit.fldSubjectFrequency.IsNullOrWhiteSpace()
                    ? currentSubject.fldSubjectFrequency
                    : subjectToEdit.fldSubjectFrequency;
                currentSubject.fldSubjectIsFacultative = subjectToEdit.fldSubjectIsFacultative;

                context.SaveChanges();
                return RedirectToAction("ManageSubjects", "SubjectList");
            }
        }

        public ActionResult DeleteSubject(int id)
        {
            int loggedUserID;
            try
            {
                loggedUserID = (int)Session["userID"];
                using (var context = new TSMEntities())
                {
                    var isAdmin = context.tblUserTypeLinks.FirstOrDefault(utl => utl.fldUserID == loggedUserID);
                    if (isAdmin.fldUserTypeID != 2) //not admin
                        return View("_AccessDenied");

                    var subjectToDelete = context.tblSubjects.FirstOrDefault(s => s.fldSubjectID == id);

                    context.tblSubjects.Remove(subjectToDelete);
                    context.SaveChanges();
                    return RedirectToAction("ManageSubjects", "SubjectList");
                }
            }
            catch (Exception)
            {
                return View("_AccessDenied");
            }
        }

    }
}