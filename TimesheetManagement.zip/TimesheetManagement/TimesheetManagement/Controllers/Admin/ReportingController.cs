﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ParseWebsite;
using TimesheetManagement.Models;
using TimesheetManagement.Models.Reporting;

namespace TimesheetManagement.Controllers.Admin
{
    public class ReportingController : Controller
    {
        TSMEntities context = new TSMEntities();
        // GET: Reporting
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult RatioGender()
        {
            return View();
        }

        public ActionResult GetGenderData()
        {
            int male = context.tblUsers.Where(u => u.fldGender == "Male").Count();
            int female = context.tblUsers.Where(u => u.fldGender == "Female").Count();
            int others = context.tblUsers.Where(u => u.fldGender == "N/A").Count();

            RatioGender obj = new RatioGender();
            obj.Male = male;
            obj.Female = female;
            obj.Others = others;

            return Json(obj, JsonRequestBehavior.AllowGet);
        }

        public ActionResult FeedbackReport()
        {
            return View();
        }

        public ActionResult GetFeedbackData()
        {
            FeedbackRatio obj = new FeedbackRatio();

            obj.option1 = context.tblFeedbacks.Count(f => f.fldFeedbackMessage == "I have a job and the hour is not convenient for me");
            obj.option2 = context.tblFeedbacks.Count(f => f.fldFeedbackMessage == "I cannot wake up so early");
            obj.option3 = context.tblFeedbacks.Count(f => f.fldFeedbackMessage == "I cannot focus this late");
            obj.option4 = context.tblFeedbacks.Count(f => f.fldFeedbackMessage == "The new teacher is helping me learn more");
            obj.option5 = context.tblFeedbacks.Count(f => f.fldFeedbackMessage == "The current teacher methods are not working for me");
            obj.option6 = context.tblFeedbacks.Count(f => f.fldFeedbackMessage == "I heard it's easier to promote the new class");
            obj.option7 = context.tblFeedbacks.Count(f => f.fldFeedbackMessage == "I heard it's very difficult to promote the old class");
            obj.option8 = context.tblFeedbacks.Count(f => f.fldFeedbackMessage == "Others");

            return Json(obj, JsonRequestBehavior.AllowGet);
        }

        public ActionResult AgeDistribution()
        {
            return View();
        }

        public ActionResult GetAgeDate()
        {
            RatioAge obj = new RatioAge();

            obj.category1 = (from u in context.tblUsers
                where DateTime.Now.Year - u.fldDateOfBirth.Value.Year < 20
                select u).ToList().Count();

            obj.category2 = (from u in context.tblUsers
                where DateTime.Now.Year - u.fldDateOfBirth.Value.Year >= 20
                where DateTime.Now.Year - u.fldDateOfBirth.Value.Year <= 25
                select u).ToList().Count();

            obj.category3 = (from u in context.tblUsers
                where DateTime.Now.Year - u.fldDateOfBirth.Value.Year >= 26
                where DateTime.Now.Year - u.fldDateOfBirth.Value.Year <= 30
                select u).ToList().Count();

            obj.category4 = (from u in context.tblUsers
                where DateTime.Now.Year - u.fldDateOfBirth.Value.Year >= 31
                select u).ToList().Count();

            return Json(obj, JsonRequestBehavior.AllowGet);
        }

        public ActionResult YearDistribution()
        {
            return View();
        }

        public ActionResult GetYearData()
        {
            YearDistribution obj = new YearDistribution();

            obj.year1 = context.tblUsers.Count(u => u.fldGroup.Contains("I1"));
            obj.year2 = context.tblUsers.Count(u => u.fldGroup.Contains("I2"));
            obj.year3 = context.tblUsers.Count(u => u.fldGroup.Contains("I3"));
            return Json(obj, JsonRequestBehavior.AllowGet);
        }

    }
}