﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ParseWebsite;
using TimesheetManagement.Models;

namespace TimesheetManagement.Controllers
{
    public class AdminHomeController : Controller
    {
        // GET: AdminHome
        public ActionResult Index()
        {
            return View();
        }

       public ActionResult SubjectsList()
        {
            int loggedUserID;
            try
            {
                loggedUserID = (int) Session["userID"];
                return View("_AccessDenied");
            }
            catch (Exception)
            {
                return View("_AccessDenied");
            }
        }

        
    }
}