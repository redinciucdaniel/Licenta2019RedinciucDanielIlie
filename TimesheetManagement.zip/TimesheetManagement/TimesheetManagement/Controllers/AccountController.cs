﻿using System;
using System.Linq;
using System.Web.Mvc;
using TimesheetManagement.Models;
using System.Security.Cryptography;
using System.Text;
using ParseWebsite;

namespace TimesheetManagement.Controllers
{
    public class AccountController : Controller
    {

        [HttpGet]
        public ActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public ActionResult LoginVerify(AccountModel account)
        {
            bool loginSuccessful = false;
            bool infoFilled = false;
            using (var context = new TSMEntities())
            {
                var user = context.tblUsers.FirstOrDefault(u => u.fldUsername == account.fldUsername);
                if (user != null)
                {
                    if (user.fldPassword == CreateMD5(CreateMD5(account.fldPassword)))
                    {
                        loginSuccessful = true;
                    }
                }

                if (user.fldAddress != null)
                    infoFilled = true;

                if (loginSuccessful)
                {
                    Session["userID"] = user.fldUserID;
                    var checkRole = context.tblUserTypeLinks.FirstOrDefault(ul => ul.fldUserID == user.fldUserID);
                    if (checkRole.fldUserTypeID == 1)
                        return RedirectToAction("Index", "StudentHome");
                    else
                        return RedirectToAction("Index", "AdminHome");
                }   
                else
                    return View("Login", account);
            }
        }

        [HttpGet]
        public ActionResult Register()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Register(tblUser account)
        {
            using (var context = new TSMEntities())
            {
                var check1 = context.tblUsers.FirstOrDefault(u => u.fldUsername == account.fldUsername);
                var check2 = context.tblUsers.FirstOrDefault(u => u.fldEmail == account.fldEmail);

                account.fldPassword = CreateMD5(CreateMD5(account.fldPassword));

                context.tblUsers.Add(account);

                if (check1 != null || check2 != null)
                {
                    if (check1 != null)
                        ViewBag.username = "This username is taken";
                    if (check2 != null)
                        ViewBag.email = "This email is already used";
                    return View("Register");
                }

                try
                {
                    context.SaveChanges();

                    var newUser = context.tblUsers.FirstOrDefault(u => u.fldUsername == account.fldUsername);
                    var userType = new tblUserTypeLink();
                    userType.fldUserID = newUser.fldUserID;
                    userType.fldUserTypeID = 1;
                    userType.fldUserTypeLinkStartDate = DateTime.Now;
                    userType.fldUserTypeLinkEndDate = DateTime.Parse("31 Dec 2059");
                    context.tblUserTypeLinks.Add(userType);
                    context.SaveChanges();

                    return View("Login");
                }
                catch (Exception)
                {
                    return View("Register");
                }
            }

        }

        [HttpGet]
        public ActionResult LogOff()
        {
            Session["userID"] = "";
            return View("Login");
        }

        public static string CreateMD5(string input)
        {
            StringBuilder hash = new StringBuilder();
            MD5CryptoServiceProvider md5provider = new MD5CryptoServiceProvider();
            byte[] bytes = md5provider.ComputeHash(new UTF8Encoding().GetBytes(input));

            for (int i = 0; i < bytes.Length; i++)
            {
                hash.Append(bytes[i].ToString("x2"));
            }
            return hash.ToString();
        }
    }
}