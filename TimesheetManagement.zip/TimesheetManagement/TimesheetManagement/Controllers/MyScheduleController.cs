﻿using System;
using System.Collections.Generic;
using System.Data.Entity.SqlServer;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Web.Mvc;
using ParseWebsite;
using TimesheetManagement.Auxx;
using TimesheetManagement.Models;

namespace TimesheetManagement.Controllers
{
    public class MyScheduleController : Controller
    {
        public ActionResult Index()
        {
            int loggedID = 0;
            try
            {
                loggedID = (int) Session["userID"];
            }
            catch (Exception)
            {
                return View("Error");
            }

            RefreshIfNeeded(loggedID);
            ScheduleModel userClasses = new ScheduleModel();
            using (var context = new TSMEntities())
            {
                var timesheetVersion = (from c in context.tblTimesheetVersions
                    where c.fldTimesheetVersionStartDate < DateTime.Now
                    where c.fldTimesheetVersionEndDate > DateTime.Now
                    select c).FirstOrDefault();

                string[] Exams = {"Examen", "Restante", "Testpractic", "Proiecte"};
                string[] Mandatory = {"Laborator", "Seminar", "Curs"};
                string[] NoChangeAllowed = {"Curs", "Examen", "Restante", "Testpractic" };
                
                List<tblClassLink> classLinksIDList= new List<tblClassLink>();
                classLinksIDList = (from cl in context.tblClassLinks
                    join c in context.tblClasses on cl.fldClassID equals c.fldClassID
                    where cl.fldUserID == loggedID
                    where c.fldTimesheetVersionID == timesheetVersion.fldTimesheetVersionID
                    select cl).ToList();

                userClasses.MandatoryList = new List<ClassModel>();
                userClasses.OptionalList = new List<ClassModel>();
                userClasses.ExamsList = new List<ClassModel>();
                userClasses.OthersList = new List<ClassModel>();

                foreach (var classLink in classLinksIDList)
                {
                    ClassModel newClass = new ClassModel();
                    var cl = context.tblClasses.FirstOrDefault(c => c.fldClassID == classLink.fldClassID);

                    newClass.fldClassLinkID = classLink.fldClassLinkID;
                    newClass.fldClassID = cl.fldClassID;
                    newClass.fldClassName = cl.fldClassName;
                    newClass.fldClassRoom = cl.fldClassRoom;
                    newClass.fldClassTeacher = cl.fldClassTeacher;
                    newClass.fldClassTimeFrom = cl.fldClassTimeFrom;
                    newClass.fldClassTimeTo = cl.fldClassTimeTo;
                    newClass.fldDayOfTheWeek = cl.fldDayOfTheWeek;
                    newClass.fldClassType = cl.fldClassType;
                    newClass.fldGroup = cl.fldGroup;
                    newClass.fldSubjectID = cl.fldSubjectID;
                    newClass.fldOptionalPackage = cl.fldOptionalPackage;
                    newClass.Editable = !NoChangeAllowed.Contains(cl.fldClassType);

                    if (Exams.Contains(newClass.fldClassType))
                    {
                        userClasses.ExamsList.Add(newClass);
                    }
                    else if (Mandatory.Contains(newClass.fldClassType))
                    {
                        var subject =
                            context.tblSubjects.FirstOrDefault(s => s.fldSubjectID == newClass.fldSubjectID);
                        int n;
                        bool isOptional = int.TryParse(newClass.fldOptionalPackage, out n);
                        
                        if (subject.fldSubjectIsFacultative  == 1)
                        {
                            userClasses.OthersList.Add(newClass);
                        }
                        else if (isOptional)
                        {
                            userClasses.OptionalList.Add(newClass);
                        }
                        else
                        {
                            userClasses.MandatoryList.Add(newClass);
                        }
                    }
                    else
                    {
                        userClasses.OthersList.Add(newClass);
                    }
                }

                if (userClasses.MandatoryList.Count > 0 || userClasses.ExamsList.Count > 0  || userClasses.OthersList.Count>0)
                {
                    userClasses.MandatoryList = userClasses.MandatoryList
                        .OrderBy(o => Utils.GetDayOfWeek(o.fldDayOfTheWeek)).ThenBy(l => l.fldClassTimeFrom).ToList();
                    userClasses.ExamsList = userClasses.ExamsList.OrderBy(o => Utils.GetDayOfWeek(o.fldDayOfTheWeek))
                        .ThenBy(l => l.fldClassTimeFrom).ToList();
                    userClasses.OthersList = userClasses.OthersList.OrderBy(o => Utils.GetDayOfWeek(o.fldDayOfTheWeek))
                        .ThenBy(l => l.fldClassTimeFrom).ToList();
                    userClasses.OptionalList = userClasses.OptionalList.OrderBy(o => Utils.GetDayOfWeek(o.fldDayOfTheWeek))
                        .ThenBy(l => l.fldClassTimeFrom).ToList();

                    return View(userClasses);
                }
                else
                    return View("NoGroupError");
            }
        }


        public ActionResult PickOptional()
        {
            int loggedUserID = 0;
            try
            {
                loggedUserID = (int) Session["userID"];
                using (var context = new TSMEntities())
                {
                    var timesheetVersion = (from c in context.tblTimesheetVersions
                        where c.fldTimesheetVersionStartDate < DateTime.Now
                        where c.fldTimesheetVersionEndDate > DateTime.Now
                        select c).FirstOrDefault();

                    var usergroup = context.tblUsers.FirstOrDefault(u => u.fldUserID == loggedUserID);

                    List<tblClass> optionalClasses = new List<tblClass>();

                    List<SubjectModel> optionalSubjects = new List<SubjectModel>();

                    optionalSubjects = (from c in context.tblClasses
                        join s in context.tblSubjects on c.fldSubjectID equals s.fldSubjectID
                        where c.fldTimesheetVersionID == timesheetVersion.fldTimesheetVersionID
                        where c.fldGroup.Contains(usergroup.fldGroup)
                        where SqlFunctions.IsNumeric(c.fldOptionalPackage.Trim()) == 1
                        select new SubjectModel()
                        {
                            fldSubjectID = s.fldSubjectID,
                            fldSubjectYear = s.fldSubjectYear,
                            fldSubjectSemester = s.fldSubjectSemester,
                            fldSubjectName = s.fldSubjectName,
                            fldSubjectFile = s.fldSubjectFile,
                            fldSubjectTarget = s.fldSubjectTarget,
                            fldSubjectIsFacultative = s.fldSubjectIsFacultative
                        }).ToList();

                    //optionalClasses = (from c in context.tblClasses
                    //    join cl in context.tblClassLinks on c.fldClassID equals cl.fldClassID
                    //    where c.fldTimesheetVersionID == timesheetVersion.fldTimesheetVersionID
                    //    where cl.fldUserID == loggedUserID
                    //    where SqlFunctions.IsNumeric(c.fldOptionalPackage.Trim()) == 1
                    //    select c).ToList();

                    return View(optionalSubjects);


                }


                return View();
            }
            catch (Exception)
            {
                return View("_AccessDenied");
            }
            
        }

        [HttpPost]
        public JsonResult SaveEvent(EventModel e)
        {
            var status = false;
            using (var context = new TSMEntities())
            {
                if (e.EventId > 0)
                {
                    var v = context.tblEvents.Where(ev => ev.fldEventID == e.EventId).FirstOrDefault();
                    if (v != null)
                    {
                        v.fldEventTitle = e.EventTitle;
                        v.fldEventDescription = e.EventDescription;
                        v.fldEventStartTime = e.EventStartTime;
                        v.fldEventEndTime = e.EventEndTime;
                        v.fldIsFullDay = e.IsFullDay;
                        v.fldThemeColor = e.EventThemeColor;
                    }
                }
                else
                {
                    var newEvent = new tblEvent();
                    newEvent.fldEventDescription = e.EventDescription;
                    newEvent.fldEventTitle = e.EventTitle;
                    newEvent.fldEventStartTime = e.EventStartTime;
                    newEvent.fldEventEndTime = e.EventEndTime;
                    newEvent.fldIsFullDay = e.IsFullDay;
                    newEvent.fldThemeColor = e.EventThemeColor;
                    newEvent.fldUserID = (int) Session["userID"];

                    context.tblEvents.Add(newEvent);
                }

                context.SaveChanges();
                status = true;
            }
            return new JsonResult {Data = new {status = status}};
        }

        [HttpPost]
        public JsonResult DeleteEvent(int eventID, int isClass)
        {
            var status = false;
            int loggedUserId = (int) Session["userID"];
            using (var context = new TSMEntities())
            {
                if (isClass != 0) //the received ID is a class link
                {
                    var timesheetVersion = (from c in context.tblTimesheetVersions
                        where c.fldTimesheetVersionStartDate < DateTime.Now
                        where c.fldTimesheetVersionEndDate > DateTime.Now
                        select c).FirstOrDefault();

                    var v = context.tblClassLinks.FirstOrDefault(cl => cl.fldClassLinkID == eventID);

                    context.tblClassLinks.Remove(v);
                    context.SaveChanges();
                    status = true;
                }
                else //the received ID is a custom event
                {
                    var v = context.tblEvents.FirstOrDefault(ev => ev.fldEventID == eventID);
                    if (v != null)
                    {
                        context.tblEvents.Remove(v);
                        context.SaveChanges();
                        status = true;
                    }
                }
                
            }
            return new JsonResult {Data = new {status = status}};
        }

        public ActionResult VisualSchedule()
        {
            return View();
        }


        #region Get all classes of the current user
        public ActionResult GetCalendarData()
        {
            JsonResult result = new JsonResult();

            try
            {
                List<EventModel> data = this.LoadData();
                result = this.Json(data, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                // Info  
                Console.Write(ex);
            }

            // Return info.  
            return result;
        }
        #endregion

        #region Load all the classes as events
        private List<EventModel> LoadData()
        {
            int loggedUserID = (int) Session["userID"];
            using (var context = new TSMEntities())
            {

                var timesheetVersion = (from c in context.tblTimesheetVersions
                    where c.fldTimesheetVersionStartDate < DateTime.Now
                    where c.fldTimesheetVersionEndDate > DateTime.Now
                    select c).FirstOrDefault();

                var events = (from c in context.tblClasses
                    join cl in context.tblClassLinks on c.fldClassID equals cl.fldClassID
                    where cl.fldUserID == loggedUserID
                    where c.fldTimesheetVersionID == timesheetVersion.fldTimesheetVersionID
                    select new EventModel()
                    {
                        EventId = cl.fldClassLinkID,
                        EventTitle = c.fldClassName,
                        EventDescription = c.fldClassRoom + " " + c.fldClassTeacher + " " + c.fldClassType,
                        HourFrom = c.fldClassTimeFrom,
                        HourTo = c.fldClassTimeTo,
                        EventThemeColor = "#B5788B",
                        DayOfTheWeek = c.fldDayOfTheWeek,
                        IsFullDay = false,
                        IsClass = cl.fldClassLinkID
                    }).ToList();

                foreach(var ev in events)
                {
                    //Get date of current Sunday
                    var firstWeekDay = DateTime.Today.AddDays(-(int)DateTime.Today.DayOfWeek);
                    ev.EventThemeColor = GetColor(ev.EventDescription.Split(' ')[2]);
                    ev.EventThemeColor = "#4C0000";

                    DateTime currentDay;
                    if (!ev.DayOfTheWeek.Contains("|"))
                    {
                        switch (ev.DayOfTheWeek)
                        {
                            case "Luni":
                                currentDay = firstWeekDay.AddDays(1);
                                break;
                            case "Marti":
                                currentDay = firstWeekDay.AddDays(2);
                                break;
                            case "Miercuri":
                                currentDay = firstWeekDay.AddDays(3);
                                break;
                            case "Joi":
                                currentDay = firstWeekDay.AddDays(4);
                                break;
                            case "Vineri":
                                currentDay = firstWeekDay.AddDays(5);
                                break;
                            case "Sambata":
                                currentDay = firstWeekDay.AddDays(6);
                                break;
                            case "Duminica":
                                currentDay = firstWeekDay.AddDays(7);
                                break;
                            default:
                                currentDay = firstWeekDay;
                                break;
                        }

                        ev.EventStartTime = currentDay.Add(TimeSpan.Parse(ev.HourFrom));
                        ev.EventEndTime = currentDay.Add(TimeSpan.Parse(ev.HourTo));
                    }
                    else
                    {
                        string testDate = ev.DayOfTheWeek.Split('|')[1]; //Replace(".", "-");
                        DateTime dt;
                        DateTime.TryParseExact(testDate,
                            "dd'.'MM'.'yyyy",
                            CultureInfo.InvariantCulture,
                            DateTimeStyles.None,
                            out dt);

                        ev.EventStartTime = dt.Add(TimeSpan.Parse(ev.HourFrom));
                        ev.EventEndTime = dt.Add(TimeSpan.Parse(ev.HourTo));
                    }

                    //if (ev.EventDescription.Contains("Laborator")
                    //    || ev.EventDescription.Contains("Seminar"))
                    //{
                    //    ev.EventThemeColor = "#6DA363";
                    //}
                    //else if (ev.EventDescription.Contains("Curs"))
                    //{
                    //    ev.EventThemeColor = "#2B4127";
                    //}
                    //else
                    //{
                    //    ev.EventThemeColor = "#B5788B";
                    //}
                }

                List<EventModel> eventList = new List<EventModel>();
                eventList = (from e in context.tblEvents
                        where e.fldUserID == loggedUserID
                        select new EventModel()
                        {
                            EventId = e.fldEventID,
                            EventTitle = e.fldEventTitle,
                            EventDescription = e.fldEventDescription,
                            EventStartTime = e.fldEventStartTime,
                            EventEndTime = e.fldEventEndTime,
                            EventThemeColor = e.fldThemeColor,
                            IsFullDay = e.fldIsFullDay,
                            IsClass = 0
                        }).ToList();

                events.AddRange(eventList);

                return events;
            }
        }
        #endregion

        private string GetColor(string ClassType)
        {
            switch (ClassType)
            {
                case "Curs":
                    return "#00485C";
                case "Laborator":
                    return "#76E482";
                case "Seminar":
                    return "#76E482";
                default:
                    return "#A21C1C";
            }
        }

        public static void RefreshIfNeeded(int loggedId)
        {
            using (var context = new TSMEntities())
            {
                var timesheetVersion = (from c in context.tblTimesheetVersions
                    where c.fldTimesheetVersionStartDate < DateTime.Now
                    where c.fldTimesheetVersionEndDate > DateTime.Now
                    select c).FirstOrDefault();

                var check = (from cl in context.tblClassLinks
                    join c in context.tblClasses on cl.fldClassID equals c.fldClassID
                    where c.fldTimesheetVersionID == timesheetVersion.fldTimesheetVersionID
                    where cl.fldUserID == loggedId
                    select cl).FirstOrDefault();

                if (check == null)
                {
                    var group = context.tblUsers.FirstOrDefault(u => u.fldUserID == loggedId);
                    context.Database.ExecuteSqlCommand("exec spUpdateClassLinks @fldUserID, @fldGroupName",
                        new SqlParameter("@fldUserID", loggedId),
                        new SqlParameter("@fldGroupName", group.fldGroup)
                    );
                }
            }
        }



    }
}