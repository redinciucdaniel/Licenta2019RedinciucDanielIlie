﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TimesheetManagement.Models
{
    public class ClassLinkModel
    {
        public ClassLinkModel(int? fldClassID, int? fldUserID, int isBackLog)
        {
            FldClassID = fldClassID;
            FldUserID = fldUserID;
            IsBackLog = isBackLog;
        }

        public int FldClassLinkID { get; set; }
        public Nullable<int> FldClassID { get; set; }
        public Nullable<int> FldUserID { get; set; }
        public int IsBackLog { get; set; }
    }
}