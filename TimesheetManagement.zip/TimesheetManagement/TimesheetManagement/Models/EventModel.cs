﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Drawing.Printing;
using System.Linq;
using System.Web;

namespace TimesheetManagement.Models
{
    public class EventModel
    {
        public EventModel() { }

        public EventModel(int eventId, string eventTitle, string eventDescription, DateTime eventStartTime, DateTime eventEndTime, string eventThemeColor, bool isFullDay, string hourFrom, string hourTo, string dayOfTheWeek, int isClass)
        {
            EventId = eventId;
            EventTitle = eventTitle;
            EventDescription = eventDescription;
            EventStartTime = eventStartTime;
            EventEndTime = eventEndTime;
            EventThemeColor = eventThemeColor;
            IsFullDay = isFullDay;
            HourFrom = hourFrom;
            HourTo = hourTo;
            DayOfTheWeek = dayOfTheWeek;
            IsClass = isClass;
        }

        public int EventId { get; set;  }
        public string EventTitle { get; set; }
        public string EventDescription { get; set; }
        public DateTime? EventStartTime { get; set; }
        public DateTime? EventEndTime { get; set; }
        public string StartTime { get; set; }
        public string EndTime { get; set; }
        public string EventThemeColor { get; set; }
        public bool? IsFullDay { get; set; }
        public string HourFrom { get; set; }
        public string HourTo { get; set; }
        public string DayOfTheWeek { get; set; }
        public int IsClass { get; set; }

    }
}