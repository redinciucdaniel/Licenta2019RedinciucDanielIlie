﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace TimesheetManagement.Models
{
    public class UserModel
    {
        public int fldUserID { get; set; }
        [Display(Name = "Username")]
        public string fldUsername { get; set; }
        [Display(Name = "Password")]
        public string fldPassword { get; set; }
        [Display(Name = "Email")]
        public string fldEmail { get; set; }
        [Display(Name = "First name")]
        public string fldFirstName { get; set; }
        [Display(Name = "Last name")]
        public string fldLastName { get; set; }
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        [Display(Name = "Birthday")]
        public Nullable<System.DateTime> fldDateOfBirth { get; set; }
        [Display(Name = "Address")]
        public string fldAddress { get; set; }
        [Display(Name = "ID No")]
        public string fldIdentityNo { get; set; }
        public Nullable<int> fldIsEmailVerified { get; set; }
        public string fldProfilePic { get; set; }
        [Display(Name = "Group")]
        public string fldGroup { get; set; }
        [Display(Name = "Gender")]
        public string fldGender { get; set; }
    }
}