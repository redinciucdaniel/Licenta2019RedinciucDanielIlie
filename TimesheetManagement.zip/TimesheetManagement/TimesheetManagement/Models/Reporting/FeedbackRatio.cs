﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TimesheetManagement.Models.Reporting
{
    public class FeedbackRatio
    {
        public int option1 { get; set; }
        public int option2 { get; set; }
        public int option3 { get; set; }
        public int option4 { get; set; }
        public int option5 { get; set; }
        public int option6 { get; set; }
        public int option7 { get; set; }
        public int option8 { get; set; }
    }
}