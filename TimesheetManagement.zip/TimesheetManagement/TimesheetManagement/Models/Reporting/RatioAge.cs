﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TimesheetManagement.Models.Reporting
{
    public class RatioAge
    {
        public int category1 { get; set; }
        public int category2 { get; set; }
        public int category3 { get; set; }
        public int category4 { get; set; }
    }
}