﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TimesheetManagement.Models.Reporting
{
    public class YearDistribution
    {
        public int year1 { get; set; }
        public int year2 { get; set; }
        public int year3 { get; set; }
    }
}