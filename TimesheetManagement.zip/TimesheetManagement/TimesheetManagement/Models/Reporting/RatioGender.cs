﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TimesheetManagement.Models
{
    public class RatioGender
    {
        public int Male { get; set; }
        public int Female { get; set; }
        public int Others { get; set; }
    }
}