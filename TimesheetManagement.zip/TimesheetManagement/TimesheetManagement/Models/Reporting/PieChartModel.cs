﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TimesheetManagement.Models.Reporting
{
    public class PieChartModel
    {
        public PieChartModel() { }

        public PieChartModel(string name, string count)
        {
            this.name = name;
            this.count = count;
        }

        public string name { get; set; }
        public string count { get; set; }
    }
}