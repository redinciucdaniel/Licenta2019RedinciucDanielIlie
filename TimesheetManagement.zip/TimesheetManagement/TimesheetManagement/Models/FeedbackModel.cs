﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace TimesheetManagement.Models
{
    public class FeedbackModel
    {
        public FeedbackModel()
        {
        }

        public FeedbackModel(int fromClass, int toClass, string reasonOfChange)
        {
            FromClass = fromClass;
            ToClass = toClass;
            ReasonOfChange = reasonOfChange;
        }

        [Display(Name = "FromClassID")]
        public int FromClass { get; set; }
        [Display(Name = "ToClassID")]
        public int ToClass { get; set; }
        [Display(Name = "Feedback")]
        public string ReasonOfChange { get; set; }

    }
}