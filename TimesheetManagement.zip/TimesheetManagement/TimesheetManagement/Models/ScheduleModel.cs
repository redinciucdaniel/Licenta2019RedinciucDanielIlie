﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TimesheetManagement.Models
{
    public class ScheduleModel
    {
        public List<ClassModel> MandatoryList { get; set; }
        public List<ClassModel> ExamsList { get; set; }
        public List<ClassModel> OptionalList { get; set; }
        public List<ClassModel> OthersList { get; set; }
    }
}