﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace TimesheetManagement.Models
{
    public class ClassModel
    {
        public ClassModel() { }

        public ClassModel(int fldClassID, string fldClassName, string fldClassRoom, string fldDayOfTheWeek, string fldClassTimeFrom, string fldClassTimeTo, string fldClassTeacher, string fldClassType, string fldGroup, bool editable, string fldOptionalPackage, int fldSubjectID, bool isBacklog)
        {
            this.fldClassID = fldClassID;
            this.fldClassName = fldClassName;
            this.fldClassRoom = fldClassRoom;
            this.fldDayOfTheWeek = fldDayOfTheWeek;
            this.fldClassTimeFrom = fldClassTimeFrom;
            this.fldClassTimeTo = fldClassTimeTo;
            this.fldClassTeacher = fldClassTeacher;
            this.fldClassType = fldClassType;
            this.fldGroup = fldGroup;
            Editable = editable;
            this.fldOptionalPackage = fldOptionalPackage;
            this.fldSubjectID = fldSubjectID;
            this.isBacklog = isBacklog;
        }

        [Display(Name = "ClassLinkID")]
        public int fldClassLinkID { get; set; }
        [Display(Name = "ClassID")]
        public int fldClassID { get; set; }
        [Display(Name = "Name")]
        public string fldClassName { get; set; }
        [Display(Name = "Room")]
        public string fldClassRoom { get; set; }
        [Display(Name = "Day")]
        public string fldDayOfTheWeek { get; set; }
        [Display(Name = "From")]
        public string fldClassTimeFrom { get; set; }
        [Display(Name = "To")]
        public string fldClassTimeTo { get; set; }
        [Display(Name = "Teacher")]
        public string fldClassTeacher { get; set; }
        [Display(Name = "Type")]
        public string fldClassType { get; set; }
        [Display(Name = "Group")]
        public string fldGroup { get; set; }
        public bool Editable { get; set; }
        [Display(Name="Package")]
        public string fldOptionalPackage { get; set; }
        [Display(Name = "Subject")]
        public int fldSubjectID { get; set; }
        public bool isBacklog { get; set; }


    }
}