﻿namespace TimesheetManagement.Models
{
    public class AccountModel
    {
        public string fldUsername { get; set; }
        public string fldPassword { get; set; }
        public string fldEmail { get; set; }
    }
}