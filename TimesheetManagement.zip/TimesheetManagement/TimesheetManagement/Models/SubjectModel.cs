﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace TimesheetManagement.Models
{
    public class SubjectModel
    {
        [Display(Name = "Subject ID")]
        public int fldSubjectID { get; set; }
        [Display(Name = "Subject name")]
        public string fldSubjectName { get; set; }
        [Display(Name = "Year")]
        public Nullable<int> fldSubjectYear { get; set; }
        [Display(Name = "Semester")]
        public Nullable<int> fldSubjectSemester { get; set; }
        [Display(Name = "Subject file")]
        public string fldSubjectFile { get; set; }
        [Display(Name = "Facultative")]
        public Nullable<int> fldSubjectIsFacultative { get; set;  }
        [Display(Name = "Frequency")]
        public string fldSubjectFrequency { get; set; }

        [Display(Name = "Program")]
        public string fldSubjectTarget { get; set; }
    }
}