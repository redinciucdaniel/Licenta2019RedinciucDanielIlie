DROP PROCEDURE dbo.spUpdateClassLinks
IF OBJECT_ID('dbo.spUpdateClassLinks', 'P') IS NOT NULL DROP PROCEDURE dbo.spUpdateClassLinks;  
GO 
CREATE PROCEDURE dbo.spUpdateClassLinks  
 @fldUserID INT,  
 @fldGroupName NVARCHAR(200)  
AS  
BEGIN  
SET NOCOUNT ON  
  
declare @userGroupID nvarchar(200)  
select @userGroupID = fldGroup from tblUser with(nolock) where fldUserID = @fldUserID  

declare @timesheetVersion int
select @timesheetVersion = fldTimesheetVersionID
from tblTimesheetVersion with(nolock)
where getdate() between fldTimesheetVersionStartDate and fldTimesheetVersionEndDate
  
 --clear existing links except the packages  
 DELETE CL FROM tblClassLink CL  
 INNER JOIN tblClass C ON CL.fldClassID = C.fldClassID  
 WHERE CL.fldUserID = @fldUserID  
 and C.fldTimesheetVersionID = @timesheetVersion
 and CL.fldIsBacklog <> 1
 and ISNUMERIC(C.fldOptionalPackage) <> 1
  
 INSERT INTO tblClassLink (fldClassID, fldUserID)  
 SELECT fldClassID, @fldUserID FROM tblClass WITH(NOLOCK)  
 WHERE fldGroup LIKE '%'+@fldGroupName+'%'  
  and ISNUMERIC(tblClass.fldOptionalPackage) <> 1
  
 UNION ALL  
  
 SELECT fldClassID, @fldUserID FROM tblClass WITH(NOLOCK)  
 WHERE (fldGroup = 'I1' or REPLACE(fldGroup, ' ', '') like 'I1-%') AND @fldGroupName like 'I1%'   
  and ISNUMERIC(tblClass.fldOptionalPackage) <> 1
    
 UNION ALL  
  
 SELECT fldClassID, @fldUserID FROM tblClass WITH(NOLOCK)  
 WHERE (fldGroup = 'I2' or REPLACE(fldGroup, ' ', '')  like '%-I2-%') AND @fldGroupName like 'I2%'  
  and ISNUMERIC(tblClass.fldOptionalPackage) <> 1
   
 UNION ALL   
  
 SELECT fldClassID, @fldUserID FROM tblClass WITH(NOLOCK)  
 WHERE (fldGroup = 'I3' or REPLACE(fldGroup, ' ', '')  like '%-I3%') AND @fldGroupName like 'I3%'  
 and ISNUMERIC(tblClass.fldOptionalPackage) <> 1
  
 UNION ALL  
  
 SELECT fldClassID, @fldUserID FROM tblClass WITH(NOLOCK)  
 WHERE (fldGroup = 'I1A' or REPLACE(fldGroup, ' ', '') like 'I1A-%') AND @fldGroupName like 'I1A%'   
 and ISNUMERIC(tblClass.fldOptionalPackage) <> 1
  
 UNION ALL  
  
 SELECT fldClassID, @fldUserID FROM tblClass WITH(NOLOCK)  
 WHERE (fldGroup = 'I1B' or REPLACE(fldGroup, ' ', '') like 'I1B-%') AND @fldGroupName like 'I1B%'   
 and ISNUMERIC(tblClass.fldOptionalPackage) <> 1
  
 UNION ALL  
   
 SELECT fldClassID, @fldUserID FROM tblClass WITH(NOLOCK)  
 WHERE (fldGroup = 'I1E' or REPLACE(fldGroup, ' ', '')  like '%-I1E%') AND @fldGroupName like 'I1E%'  
 and ISNUMERIC(tblClass.fldOptionalPackage) <> 1
    
 UNION ALL  
  
 SELECT fldClassID, @fldUserID FROM tblClass WITH(NOLOCK)  
 WHERE (fldGroup = 'I2A' or REPLACE(fldGroup, ' ', '')  like '%I2A-%') AND @fldGroupName like 'I2A%'  
 and ISNUMERIC(tblClass.fldOptionalPackage) <> 1
  
 UNION ALL  
  
 SELECT fldClassID, @fldUserID FROM tblClass WITH(NOLOCK)  
 WHERE (fldGroup = 'I2B' or REPLACE(fldGroup, ' ', '')  like '%-I2B%') AND @fldGroupName like 'I2B%'  
 and ISNUMERIC(tblClass.fldOptionalPackage) <> 1
  
 UNION ALL   
  
 SELECT fldClassID, @fldUserID FROM tblClass WITH(NOLOCK)  
 WHERE (fldGroup = 'I3A' or REPLACE(fldGroup, ' ', '')  like '%I3A-%') AND @fldGroupName like 'I3A%'  
 and ISNUMERIC(tblClass.fldOptionalPackage) <> 1
  
 UNION ALL   
  
 SELECT fldClassID, @fldUserID FROM tblClass WITH(NOLOCK)  
 WHERE (fldGroup = 'I3B' or REPLACE(fldGroup, ' ', '')  like '%I3B-%') AND @fldGroupName like 'I3B%'  
 and ISNUMERIC(tblClass.fldOptionalPackage) <> 1
  
 UNION ALL   
  
 SELECT fldClassID, @fldUserID FROM tblClass WITH(NOLOCK)  
 WHERE (fldGroup = 'I3E' or REPLACE(fldGroup, ' ', '')  like '%-I3E%') AND @fldGroupName like 'I3E%'  
 and ISNUMERIC(tblClass.fldOptionalPackage) <> 1

 UNION ALL

 SELECT fldClassID, @fldUserID FROM tblClass WITH(NOLOCK)  
 WHERE (fldGroup = 'MOC1' or REPLACE(fldGroup, ' ', '')  like '%-MOC') AND @fldGroupName like 'MOC1'  
 and ISNUMERIC(tblClass.fldOptionalPackage) <> 1

 UNION ALL

 SELECT fldClassID, @fldUserID FROM tblClass WITH(NOLOCK)  
 WHERE (fldGroup = 'MOC1' or REPLACE(fldGroup, ' ', '')  like '%-MOC1-%') AND @fldGroupName like 'MOC1' 
 and ISNUMERIC(tblClass.fldOptionalPackage) <> 1

 UNION ALL

 SELECT fldClassID, @fldUserID FROM tblClass WITH(NOLOCK)  
 WHERE (fldGroup = 'MOC1' or REPLACE(fldGroup, ' ', '')  like '%MOC1-%') AND @fldGroupName like 'MOC1' 
 and ISNUMERIC(tblClass.fldOptionalPackage) <> 1

 UNION ALL

 SELECT fldClassID, @fldUserID FROM tblClass WITH(NOLOCK)  
 WHERE (fldGroup = 'MOC2' or REPLACE(fldGroup, ' ', '')  like '%-MOC') AND @fldGroupName like 'MOC2'  
 and ISNUMERIC(tblClass.fldOptionalPackage) <> 1

 UNION ALL

 SELECT fldClassID, @fldUserID FROM tblClass WITH(NOLOCK)  
 WHERE (fldGroup = 'MOC2' or REPLACE(fldGroup, ' ', '')  like '%-MOC2-%') AND @fldGroupName like 'MOC2' 
 and ISNUMERIC(tblClass.fldOptionalPackage) <> 1

 UNION ALL

 SELECT fldClassID, @fldUserID FROM tblClass WITH(NOLOCK)  
 WHERE (fldGroup = 'MOC1' or REPLACE(fldGroup, ' ', '')  like '%-MOC2%') AND @fldGroupName like 'MOC2' 
 and ISNUMERIC(tblClass.fldOptionalPackage) <> 1

 UNION ALL

 SELECT fldClassID, @fldUserID FROM tblClass WITH(NOLOCK)  
 WHERE (fldGroup = 'MIS1' or REPLACE(fldGroup, ' ', '')  like '%MIS-%') AND @fldGroupName like 'MIS1' 
 and ISNUMERIC(tblClass.fldOptionalPackage) <> 1

 UNION ALL

 SELECT fldClassID, @fldUserID FROM tblClass WITH(NOLOCK)  
 WHERE (fldGroup = 'MIS1' or REPLACE(fldGroup, ' ', '')  like '%MIS1-%') AND @fldGroupName like 'MIS1'
 and ISNUMERIC(tblClass.fldOptionalPackage) <> 1
 
 UNION ALL

 SELECT fldClassID, @fldUserID FROM tblClass WITH(NOLOCK)  
 WHERE (fldGroup = 'MIS1' or REPLACE(fldGroup, ' ', '')  like '%MIS1-%') AND @fldGroupName like 'MIS1' 
 and ISNUMERIC(tblClass.fldOptionalPackage) <> 1

 UNION ALL

 SELECT fldClassID, @fldUserID FROM tblClass WITH(NOLOCK)  
 WHERE (fldGroup = 'MIS2' or REPLACE(fldGroup, ' ', '')  like '%MIS-%') AND @fldGroupName like 'MIS2' 
 and ISNUMERIC(tblClass.fldOptionalPackage) <> 1

 UNION ALL

 SELECT fldClassID, @fldUserID FROM tblClass WITH(NOLOCK)  
 WHERE (fldGroup = 'MIS2' or REPLACE(fldGroup, ' ', '')  like '%MIS2-%') AND @fldGroupName like 'MIS2' 
 and ISNUMERIC(tblClass.fldOptionalPackage) <> 1
  
  
 --select distinct fldGroup from tblClass where fldGroup like '%I3E%'  
  
 --select * from tblClassLink CL INNER JOIN tblClass C on CL.fldClassID = C.fldClassID  
  
SET NOCOUNT OFF  
END