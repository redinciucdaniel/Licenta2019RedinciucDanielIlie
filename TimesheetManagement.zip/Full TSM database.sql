use master;
drop database TSM;
go
create database TSM;
go
use TSM2

--DROP TABLE dbo.tblUser;
--DROP TABLE dbo.tblUserType;
--DROP TABLE dbo.tblUserTypeLink;
--DROP TABLE dbo.UserInfo;
--DROP TABLE dbo.tblClassLink;
--DROP TABLE dbo.tblClass;
--DROP TABLE dbo.tblSubject;

CREATE TABLE dbo.tblUser 
(
	fldUserID INT IDENTITY(1,1),
	fldUsername NVARCHAR(200),
	fldPassword NVARCHAR(200),
	fldEmail NVARCHAR(200),
	fldFirstName NVARCHAR(200),
	fldLastName NVARCHAR(200),
	fldDateOfBirth DATETIME,
	fldAddress NVARCHAR(MAX),
	fldIdentityNo NVARCHAR(100),
	fldIsEmailVerified INT,
	--fldProfilePic NVARCHAR(200),
	fldGroup NVARCHAR(MAX),
	CONSTRAINT PK_User PRIMARY KEY(fldUserID)
);

--SELECT * FROM tblUserType
--SELECT * FROM tblUserTypeLink

--select * from tblUser
--select * from tblUserTypeLink



CREATE TABLE dbo.tblUserType
(
	fldUserTypeID INT IDENTITY(1,1),
	fldUserTypeDescription NVARCHAR(500),
	CONSTRAINT PK_UserType PRIMARY KEY(fldUserTypeID)
);
CREATE TABLE dbo.tblUserTypeLink
(
	fldUserTypeLinkID INT IDENTITY(1,1),
	fldUserTypeID INT,
	fldUserID INT,
	fldUserTypeLinkStartDate DATETIME,
	fldUserTypeLinkEndDate DATETIME,
	CONSTRAINT PK_UserTypeLink PRIMARY KEY(fldUserTypeLinkID),
	CONSTRAINT FK_UserTypeLinkUserType FOREIGN KEY(fldUserTypeID) REFERENCES tblUserType(fldUserTypeID),
	CONSTRAINT FK_UserTypeLinkUser FOREIGN KEY(fldUserID) REFERENCES tblUser(fldUserID)
);

INSERT INTO dbo.tblUserType (fldUserTypeDescription) VALUES ('Student'), ('Admin')

select * from tblUserType
--SET DATEFORMAT DMY
--INSERT INTO dbo.tblUserTypeLink (fldUserTypeID, fldUserID, fldUserTypeLinkStartDate, fldUserTypeLinkEndDate)
--VALUES (1, 1, '01/01/1900', '31/12/2059'), (1, 2, '01/01/1900', '31/12/2059')

CREATE TABLE dbo.tblSubject
(
	fldSubjectID INT IDENTITY(1,1),
	fldSubjectName NVARCHAR(MAX),
	fldSubjectYear INT,
	fldSubjectSemester INT,
	fldSubjectIsFacultative INT,
	fldSubjectFrequency NVARCHAR(100),
	fldSubjectFile nvarchar(200),
	CONSTRAINT PK_Subject PRIMARY KEY(fldSubjectID)
);

CREATE TABLE dbo.tblTimesheetVersion
(
	fldTimesheetVersionID INT IDENTITY(1,1),
	fldTimesheetVersionStartDate DATETIME,
	fldTimesheetVersionEndDate DATETIME,
	fldTimesheetVersionLastUpdateOn DATETIME,
	fldTimesheetVersionLastUpdateBy INT,
	CONSTRAINT PK_TSMVersion PRIMARY KEY(fldTimesheetVersionID)
);

CREATE TABLE dbo.tblClass
(
	fldClassID INT IDENTITY(1,1),
	fldSubjectID INT NOT NULL,
	fldClassName nvarchar(200),
	fldClassType nvarchar(200),
	fldDayOfTheWeek VARCHAR(200),
	fldClassTimeFrom VARCHAR(5),
	fldClassTimeTo VARCHAR(5),
	fldClassTeacher NVARCHAR(200),
	fldClassRoom nvarchar(200),
	fldGroup nvarchar(200),
	fldClassRoomLink nvarchar(200),
	fldTeacherLink nvarchar(200),
	fldOptionalPackage nvarchar(50),
	fldTimesheetVersionID int,
	CONSTRAINT PK_Class PRIMARY KEY(fldClassID),
	CONSTRAINT FK_ClassSubject FOREIGN KEY(fldSubjectID) REFERENCES tblSubject(fldSubjectID),
	CONSTRAINT FK_ClassTSMversion FOREIGN KEY(fldTimesheetVersionID) REFERENCES tblTimesheetVersion(fldTimesheetVersionID)
);

CREATE TABLE dbo.tblClassLink
(
	fldClassLinkID INT IDENTITY(1,1),
	fldClassID INT,
	fldUserID INT,
	fldIsBacklog INT,
	CONSTRAINT PK_ClassLink PRIMARY KEY(fldClassLinkID),
	CONSTRAINT FK_ClassLinkClass FOREIGN KEY(fldClassID) REFERENCES tblClass(fldClassID),
	CONSTRAINT FK_ClassLinkUser FOREIGN KEY(fldUserID) REFERENCES tblUser(fldUserID)
);

CREATE TABLE dbo.tblFeedback
(
	fldFeedbackID INT IDENTITY(1,1),
	fldClassIdFrom INT,
	fldClassIdTo INT,
	fldFeedbackMessage NVARCHAR(MAX),
	CONSTRAINT PK_Feedback PRIMARY KEY(fldFeedbackID),
	CONSTRAINT FK_FeedClassFrom FOREIGN KEY(fldClassIdFrom) REFERENCES tblClass(fldClassID),
	CONSTRAINT FK_FeedClassTo FOREIGN KEY(fldClassIdTo) REFERENCES tblClass(fldClassID)
);

--DROP TABLE dbo.tblEvent
CREATE TABLE dbo.tblEvent
(
	fldEventID INT IDENTITY(1,1),
	fldEventTitle nvarchar(max),
	fldEventDescription nvarchar(max),
	fldEventStartTime datetime,
	fldEventEndTime datetime,
	fldThemeColor nvarchar(10),
	fldIsFullDay bit,
	fldUserID int,
	CONSTRAINT PK_Event PRIMARY KEY(fldEventID),
	CONSTRAINT FK_EventUser FOREIGN KEY(fldUserID) REFERENCES tblUser(fldUserID)

)






--delete from tblClassLink
--delete from tblClass
--delete from tblSubject


